"""
Migration 0014 — Add is_delete column to all asset tables
Run the SQL below manually first (since all tables are managed=False),
then run: python manage.py migrate
"""
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('Server', '0013_schema_info_database_server_refactor'),
    ]

    operations = [
        # ORM state sync — actual SQL must be run manually (managed=False tables)
        migrations.AddField(
            model_name='physicalserver',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='virtualmachine',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='applicationserver',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='databaseserver',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='schemainfo',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='software',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
        migrations.AddField(
            model_name='softwaredatabasemap',
            name='is_delete',
            field=models.IntegerField(default=0),
        ),
    ]
