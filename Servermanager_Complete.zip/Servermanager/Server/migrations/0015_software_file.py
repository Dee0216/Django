from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('Server', '0014_add_is_delete_all_tables'),
    ]

    operations = [
        migrations.CreateModel(
            name='SoftwareFile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('file', models.FileField(upload_to='software_files/')),
                ('description', models.CharField(blank=True, max_length=255, null=True)),
                ('uploaded_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('is_delete', models.IntegerField(default=0)),
                ('software', models.ForeignKey(
                    db_column='software_id',
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='files',
                    to='Server.software',
                )),
            ],
            options={
                'db_table': 'software_file',
                'ordering': ['uploaded_at'],
            },
        ),
    ]
