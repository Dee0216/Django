from django.contrib import admin
from .models import AuthLog

@admin.register(AuthLog)
class AuthLogAdmin(admin.ModelAdmin):
    list_display = ('username','action','time')
    list_filter = ('action',)
# Register your models here.
