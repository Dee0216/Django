from django import forms
from .models import PhysicalServer, VirtualMachine, DatabaseServer, SchemaInfo, Software, SoftwareDatabaseMap, TblEmpdetails, ApplicationServer


class PhysicalServerForm(forms.ModelForm):
    class Meta:
        model = PhysicalServer
        fields = ['server_id', 'hostname', 'user_id', 'password', 'make', 'model',
                  'service_tag', 'purchase_no', 'purchase_date', 'warranty_expiry', 'location', 'notes']


class VirtualMachineForm(forms.ModelForm):
    class Meta:
        model = VirtualMachine
        fields = ['vm_id', 'hostname', 'user_id', 'password', 'os', 'cpu_cores',
                  'ram_gb', 'storage_gb', 'ip_address', 'physical_server', 'description']
        widgets = {
            'hostname': forms.TextInput(attrs={'class': 'form-input'}),
            'user_id': forms.TextInput(attrs={'class': 'form-input'}),
            'password': forms.PasswordInput(attrs={'class': 'form-input'}),
            'os': forms.TextInput(attrs={'class': 'form-input'}),
            'cpu_cores': forms.NumberInput(attrs={'class': 'form-input'}),
            'ram_gb': forms.NumberInput(attrs={'class': 'form-input'}),
            'storage_gb': forms.NumberInput(attrs={'class': 'form-input'}),
            'ip_address': forms.TextInput(attrs={'class': 'form-input'}),
            'physical_server': forms.Select(attrs={'class': 'form-input'}),
            'description': forms.Textarea(attrs={'class': 'form-textarea'}),
        }


class DatabaseServerForm(forms.ModelForm):
    """Form for the new DatabaseServer (logical DB server on a VM)."""
    class Meta:
        model = DatabaseServer
        fields = ['db_id', 'name', 'focal_point', 'location', 'port', 'remarks', 'vm']


class SchemaInfoForm(forms.ModelForm):
    """Form for SchemaInfo (renamed from old DatabaseServer)."""
    class Meta:
        model = SchemaInfo
        fields = ['db_id', 'db_type', 'user_id', 'password', 'version',
                  'port', 'description', 'db_name', 'database_server']


class SoftwareForm(forms.ModelForm):
    class Meta:
        model = Software
        fields = ['software_id', 'name', 'version', 'app', 'client',
                  'focal_point', 'programming_language', 'description']


class ApplicationServerForm(forms.ModelForm):
    class Meta:
        model = ApplicationServer
        fields = ['app_id', 'name', 'userid', 'password', 'location', 'focal_point', 'remarks', 'vm']


class SoftwareDatabaseMapForm(forms.ModelForm):
    class Meta:
        model = SoftwareDatabaseMap
        fields = ['id', 'software', 'db', 'description']


class TblEmpdetailsForm(forms.ModelForm):
    employeecode = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-input'}),
        label="Employee Code"
    )
    password = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-input'}),
        label="Password"
    )

    class Meta:
        model = TblEmpdetails
        fields = ['employeecode', 'salutation', 'employeename', 'designation', 'desgfullname',
                  'divncode', 'division', 'grup', 'entity', 'administrator', 'password']
        widgets = {
            'employeecode': forms.TextInput(attrs={'class': 'form-input'}),
            'employeename': forms.TextInput(attrs={'class': 'form-input'}),
        }
