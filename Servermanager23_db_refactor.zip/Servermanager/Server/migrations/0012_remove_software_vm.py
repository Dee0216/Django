from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Server', '0011_alter_software_options'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='software',
            name='vm',
        ),
    ]
