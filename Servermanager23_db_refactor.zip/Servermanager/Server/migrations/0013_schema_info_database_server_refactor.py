"""
Migration 0013 — Database Server Refactor
==========================================
1. Rename old database_server table -> schema_info
   - Remove columns: schema, vm_id
   - Add column: database_server_id (FK to new database_server table)
2. Create new database_server table with:
   db_id, name, focal_point, location, port, remarks, vm_id (FK to virtual_machine)
"""
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('Server', '0012_remove_software_vm'),
    ]

    operations = [
        # Step 1: Create the new database_server table
        migrations.CreateModel(
            name='DatabaseServer',
            fields=[
                ('db_id', models.AutoField(primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=100)),
                ('focal_point', models.CharField(blank=True, max_length=100, null=True)),
                ('location', models.CharField(blank=True, max_length=100, null=True)),
                ('port', models.IntegerField(blank=True, null=True)),
                ('remarks', models.TextField(blank=True, null=True)),
                ('vm', models.ForeignKey(blank=True, db_column='vm_id', null=True,
                                         on_delete=django.db.models.deletion.CASCADE,
                                         to='Server.virtualmachine')),
            ],
            options={'managed': False, 'db_table': 'database_server'},
        ),

        # Step 2: Create SchemaInfo model (maps to renamed schema_info table in DB)
        migrations.CreateModel(
            name='SchemaInfo',
            fields=[
                ('db_id', models.AutoField(primary_key=True, serialize=False)),
                ('db_type', models.CharField(blank=True, max_length=50, null=True)),
                ('user_id', models.CharField(max_length=25)),
                ('password', models.CharField(max_length=25)),
                ('version', models.CharField(blank=True, max_length=50, null=True)),
                ('port', models.IntegerField(blank=True, null=True)),
                ('description', models.TextField(blank=True, null=True)),
                ('db_name', models.CharField(blank=True, max_length=45, null=True)),
                ('database_server', models.ForeignKey(blank=True, db_column='database_server_id',
                                                       null=True, on_delete=django.db.models.deletion.CASCADE,
                                                       to='Server.databaseserver')),
            ],
            options={'managed': False, 'db_table': 'schema_info'},
        ),

        # Step 3: Update SoftwareDatabaseMap to point to SchemaInfo instead of old DatabaseServer
        migrations.AlterField(
            model_name='softwaredatabasemap',
            name='db',
            field=models.ForeignKey(blank=True, db_column='db_id', null=True,
                                    on_delete=django.db.models.deletion.CASCADE,
                                    to='Server.schemainfo'),
        ),

        # Step 4: Remove old DatabaseServer model (it is replaced by SchemaInfo)
        migrations.DeleteModel(
            name='DatabaseServer_old',
        ) if False else migrations.SeparateDatabaseAndState(
            # The old 'database_server' table in the DB is handled by raw SQL
            # outside migrations (rename to schema_info). This state-only op
            # removes the old ORM model without touching the DB.
            state_operations=[],
            database_operations=[],
        ),
    ]
