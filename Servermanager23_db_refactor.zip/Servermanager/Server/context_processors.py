def user_session(request):
    return{
        'administrator':request.session.get('administrator',0),
        'employeecode':request.session.get('employeecode'),
        'employeename': request.session.get('employeename'),
        'designation':request.session.get('designation'),
        'entity':request.session.get('entity'),
    }