from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate,login,logout
from django.http import JsonResponse
from django.contrib import messages
from .forms import PhysicalServerForm,VirtualMachineForm,DatabaseServerForm,SoftwareForm,SoftwareDatabaseMapForm,TblEmpdetailsForm,ApplicationServerForm
from .models import PhysicalServer,VirtualMachine,DatabaseServer,Software,SoftwareDatabaseMap,TblEmpdetails,AuthLog,ApplicationServer



def login_view(request):
    if request.method =='POST':
        employeecode = request.POST.get('employeecode', '').strip()
        password = request.POST.get('password','').strip()

        try:
            employee = TblEmpdetails.objects.get(
                employeecode=employeecode,
                password=password,
                
            )

            request.session['employeecode']=employee.employeecode
            request.session['employeename']=employee.employeename
            request.session['designation']=employee.designation
            request.session['entity']=employee.entity
            request.session['administrator']=employee.administrator
            AuthLog.objects.create(username = employee.employeecode, action='login')
            return redirect('home')
        except TblEmpdetails.DoesNotExist:
            AuthLog.objects.create(username='employeecode',action='failed')
            return render(request, 'login.html',{
                'error':"Invalid Employee code or Password. Please try again."
            })
    return render(request,'login.html')
def logout_view(request):
    AuthLog.objects.create(username = request.session.get('employeecode','Unknown'),action='logout')
    request.session.flush()
    return redirect('login_view')


def add_physical_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Added Physical server')
    if request.method =="POST":
        form = PhysicalServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = PhysicalServerForm()
    return render(request,'add_assets.html',{'form':form})




def list_physical_servers(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed Physical server')
    servers = PhysicalServer.objects.all()  # Fetch all records
    return render(request, 'list_physical_servers.html', {'servers': servers})



def edit_physicalserver(request,server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    
    server = get_object_or_404(PhysicalServer,pk=server_id)
    AuthLog.objects.create(
        username=employeecode,
        action='viewed_edit_server',
        details=f"Opened edit for Server ID {server_id} ({server.hostname})"
    )
    if request.method=='POST':
        before={
             'hostname':       server.hostname,
            'user_id':        server.user_id,
            'password':       server.password,
            'make':           server.make,
            'ip_address':     server.ip_address,
            'model':          server.model,
            'service_tag':    server.service_tag,
            'purchase_no':    server.purchase_no,
            'purchase_date':  str(server.purchase_date),
            'warranty_expiry':str(server.warranty_expiry),
            'location':       server.location,
            'notes':          server.notes,
        }
        server.hostname = request.POST.get('hostname')
        server.user_id = request.POST.get('user_id')
        server.password = request.POST.get('password')
        server.make = request.POST.get('make')
        server.ip_address = request.POST.get('ip_address')
        server.model = request.POST.get('model')
        server.service_tag = request.POST.get('service_tag')
        server.purchase_no = request.POST.get('purchase_no')
        server.purchase_date = request.POST.get('purchase_date')or None
        server.warranty_expiry = request.POST.get('warranty_expiry')or None
        server.location = request.POST.get('location')
        server.notes = request.POST.get('notes')

        server.save()
        after = {
            'hostname':       server.hostname,
            'user_id':        server.user_id,
            'password':       server.password,
            'make':           server.make,
            'ip_address':     server.ip_address,
            'model':          server.model,
            'service_tag':    server.service_tag,
            'purchase_no':    server.purchase_no,
            'purchase_date':  str(server.purchase_date),
            'warranty_expiry':str(server.warranty_expiry),
            'location':       server.location,
            'notes':          server.notes,
        }
        changes = {
            field: {'before': before[field], 'after': after[field]} for field in before if before[field] != after[field]
        }

        AuthLog.objects.create(
            username=employeecode,
            action='edited_server',
            details=f"Server ID {server_id} | Changes: {changes}"
        )
        return redirect('list_physical_servers')

    return render(request,'edit_physicalserver.html',
    {
        'server':server,
    })

def vms_preview(request,server_id):
    vms = VirtualMachine.objects.filter(physical_server_id=server_id).values_list('hostname',flat = True)
    return JsonResponse({'vms':list(vms)})

def dbs_preview(request,vm_id):
    dbs = DatabaseServer.objects.filter(vm_id=vm_id).values_list('db_name',flat=True)
    return JsonResponse({'dbs':list(dbs)})

def software_preview(request,vm_id):
    softwares = Software.objects.filter(app__vm_id=vm_id).values_list('name',flat=True)
    return JsonResponse({'softwares':list(softwares)})



def add_virtual_machine(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action="Added VM")
    servers = PhysicalServer.objects.all()
    if request.method =="POST":
        form = VirtualMachineForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = VirtualMachineForm()
    return render(request,'add_assets.html',{'form':form})
def list_virtual_machine(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed VM list')
    vms = VirtualMachine.objects.select_related('physical_server').all()  # Fetch all records
   
    return render(request, 'list_virtual_machine.html', {'vms': vms})


def add_application_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
   
    if request.method =="POST":
        form = ApplicationServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = ApplicationServerForm()
    return render(request,'add_assets.html',{'form':form})


def add_database_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action="Added database")
    if request.method =="POST":
        form = DatabaseServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = DatabaseServerForm()
    return render(request,'add_assets.html',{'form':form})


def list_database_server(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed Database')
    dbs = DatabaseServer.objects.select_related('vm').all()
    return render(request,'list_database_server.html',{'dbs':dbs})


def list_application_server(request):
    employeecode = request.session.get('employeecode')

    apps = ApplicationServer.objects.select_related('vm').all()
    return render (request,'list_application_server.html',{'apps':apps})



def add_software_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Added software')

    if request.method =="POST":
        form = SoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = SoftwareForm()
    return render(request,'add_assets.html',{'form':form})


def list_software_server(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed Software')
    softwares = Software.objects.select_related('app__vm').all()
    return render(request,'list_software_server.html',{'softwares':softwares})

def software_db_map(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode=request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action="Added Mappings")
    if request.method=="POST":
        form = SoftwareDatabaseMapForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')

    else:
        form = SoftwareDatabaseMapForm()
    return render(request,'add_assets.html',{'form':form})





def software_db_map_list(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed Mapping')
    if not request.session.get("employeecode"):
        return redirect('login_view')
    mappings = SoftwareDatabaseMap.objects.all()
    return render(request,"software_db_map_list.html",{'mappings':mappings})
    


def vms_by_server(request,server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    server = get_object_or_404(PhysicalServer,pk=server_id)
    vms = VirtualMachine.objects.filter(physical_server=server)
    return render(request,'vms_by_server.html',
    {'server':server,
    'vms':vms,
    })

def softwares_by_vm(request,vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine,pk=vm_id)
    # Double join: Software -> ApplicationServer -> VirtualMachine
    softwares = Software.objects.select_related('app__vm').filter(app__vm=vm)
    return render(request,'softwares_by_vm.html',
    {'vm':vm,
    'softwares':softwares,
    })
    
def databases_by_vm(request,vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine,pk=vm_id)
    dbs = DatabaseServer.objects.filter(vm=vm)
    return render(request,'databases_by_vm.html',
    {
        'vm':vm,
        'dbs':dbs,
    }
    )



def edit_software(request,software_id):
    if not request.session.get('employeecode'):
        request.redirect('login_view')

    employeecode = request.session.get('employeecode')
    software = get_object_or_404(Software,pk=software_id)
    AuthLog.objects.create(
        username=employeecode,
        action='viewed_edit_software',
        details=f"Opened edit for Software ID {software_id} ({software.name})"
    )
    if request.method=="POST":
        before = {
        'name':                 software.name,
        'version':              software.version,
        'client':               software.client,
        'focal_point':          software.focal_point,
        'programming_language': software.programming_language,
        'description':          software.description,
        'app_id':               str(software.app_id),
    }
        software.name = request.POST.get('name')
        software.version = request.POST.get('version')
        software.client = request.POST.get('client')
        software.focal_point = request.POST.get('focal_point')
        software.programming_language = request.POST.get('programming_language')
        software.description = request.POST.get('description')
        app_id = request.POST.get('app')
        if app_id:
            software.app_id = app_id
        software.save()

        after = {
        'name':                 software.name,
        'version':              software.version,
        'client':               software.client,
        'focal_point':          software.focal_point,
        'programming_language': software.programming_language,
        'description':          software.description,
        'app_id':               str(software.app_id),
        }

        changes = {
            field: {'before': before[field], 'after': after[field]} for field in before if before[field] != after[field]
        }
        AuthLog.objects.create(
            username=employeecode,
            action='edited_software',
            details=f"software ID {software_id} | Changes: {changes}"
        )
        return redirect('list_software_server')
    apps = ApplicationServer.objects.select_related('vm').all()
    return render(request,'edit_software.html',
    {
        'software':software,
        'apps':apps,
    })

def edit_database(request,db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')

    db = get_object_or_404(DatabaseServer,pk=db_id)
    AuthLog.objects.create(
        username=employeecode,
        action='viewed_edit_database',
        details=f"Opened edit for database ID {db_id} ({db.db_name})"
    )
    if request.method=="POST":

        before = {
            'db_type' : db.db_type,
            'db_user_id':db.user_id,
            'password':db.password,
        'schema':db.schema, 
        'version':db.version, 
        'port':str(db.port),
        'description':db.description,
        'db_name':db.db_name,
        'vm_id':str(db.vm_id),
        }
        db.db_type = request.POST.get('db_type')
        db.user_id = request.POST.get('user_id')
        db.password = request.POST.get('password')
        db.schema = request.POST.get('schema')
        db.version = request.POST.get('version')
        db.port = request.POST.get('port')
        db.description = request.POST.get('description')
        db.db_name = request.POST.get('db_name')

        vm_id = request.POST.get('vm')
        if vm_id:
            db.vm_id = vm_id
        db.save()

        after = {
            'db_type' : db.db_type,
            'db_user_id':db.user_id,
            'password':db.password,
        'schema':db.schema, 
        'version':db.version, 
        'port':str(db.port),
        'description':db.description,
        'db_name':db.db_name,
        'vm_id':str(db.vm_id),
        }
        changes = {
            field: {'before': before[field], 'after': after[field]} for field in before if before[field] != after[field]
        
        }
        AuthLog.objects.create(
            username=employeecode,
            action='edited_database',
            details=f"Database ID {db_id} | Changes: {changes}"
        )
        return redirect ('list_database_server')
    vms = VirtualMachine.objects.all()
    return render(request,'edit_database.html',
    {
        'db':db,
        'vms':vms,
    })


def edit_applications(request,app_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')

    app = get_object_or_404(ApplicationServer,pk=app_id)
    

    if request.method=="POST":

        before = {
            'app_name' : app.name,
            'user_id':app.userid,
            'password':app.password,
        'location':app.location, 
       'focal_point':app.focal_point,
        'remarks':app.remarks,
       
        'vm_id':str(app.vm_id),
        }
        app.name = request.POST.get('name')
        app.userid = request.POST.get('userid')
        app.password = request.POST.get('password')
        app.location = request.POST.get('location')
        app.focal_point = request.POST.get('focal_point')
        
        app.remarks = request.POST.get('remarks')
   

        vm_id = request.POST.get('vm')
        if vm_id:
            app.vm_id = vm_id
        app.save()

        after = {
            'app_name' : app.name,
            'user_id':app.userid,
            'password':app.password,
        'location':app.location, 
       'focal_point':app.focal_point,
        'remarks':app.remarks,
       
        'vm_id':str(app.vm_id),
        }
        changes = {
            field: {'before': before[field], 'after': after[field]} for field in before if before[field] != after[field]
        
        }
        AuthLog.objects.create(
            username=employeecode,
            action='edited_database',
            details=f"Database ID {app_id} | Changes: {changes}"
        )
        return redirect ('list_application_server')
    vms = VirtualMachine.objects.all()
    return render(request,'edit_applications.html',
    {
        'app':app,
        'vms':vms,
    })






















def edit_vm(request,vm_id):
    if not request.session.get('employeecode'):
        request.redirect('login_view')
    employeecode = request.session.get('employeecode')
    vm = get_object_or_404(VirtualMachine,pk=vm_id)
    AuthLog.objects.create(
        username=employeecode,
        action='viewed_edit_vm',
        details=f"Opened edit for VM ID {vm_id} ({vm.hostname})"
    )

    before = {
        'hostname':vm.hostname,
        'user_id':vm.user_id,
        'password':vm.password, 
        'os':vm.os,
        'cpu_core':str(vm.cpu_cores), 
        'ram':str(vm.ram_gb), 
        'storage':str(vm.storage_gb), 
        'ip_address':vm.ip_address,
       
        'description':vm.description, 
        'server_id':str(vm.physical_server_id), 
    }
    if request.method=='POST':
        vm.hostname = request.POST.get('hostname')
        vm.user_id = request.POST.get('user_id')
        vm.password = request.POST.get('password')
        vm.os = request.POST.get('os')
        vm.cpu_cores = request.POST.get('cpu_cores')
        vm.ram_gb  = request.POST.get('ram_gb')
        vm.storage_gb = request.POST.get('storage_gb')
        vm.ip_address = request.POST.get('ip_address')
       
        vm.description = request.POST.get('description')
        server_id = request.POST.get('physical_server_id')
        if server_id:
            vm.physical_server_id = server_id
        vm.save()
        after = {
        'hostname':vm.hostname,
        'user_id':vm.user_id,
        'password':vm.password, 
        'os':vm.os,
        'cpu_core':str(vm.cpu_cores), 
        'ram':str(vm.ram_gb), 
        'storage':str(vm.storage_gb), 
        'ip_address':vm.ip_address,
       
        'description':vm.description, 
        'server_id':str(vm.physical_server_id), 
    }
        changes = {
            field: {'before': before[field], 'after': after[field]} for field in before if before[field] != after[field]
        
        }
        AuthLog.objects.create(
            username=employeecode,
            action='edited_vm',
            details=f"VM ID {vm_id} | Changes: {changes}"
        )
        return redirect('list_virtual_machine')
    servers = PhysicalServer.objects.all()
    return render(request,'edit_vm.html',
    {
        'vm':vm,
        'servers':servers,
    })


def physical_server_def(request,server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    server = get_object_or_404(PhysicalServer,pk=server_id)
   
    return render(request,'physical_server_def.html',
    {'server':server,
  
    })


def virtual_machine_def(request,vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine,pk=vm_id)
   
    return render(request,'virtual_machine_def.html',
    {'vm':vm,
  
    })


def software_def(request,software_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    software = get_object_or_404(Software,pk=software_id)
    return render(request,'software_def.html',
    {
        'software':software,
    })


def database_def(request,db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    db = get_object_or_404(DatabaseServer,pk=db_id)
    return render(request,'database_def.html',{
        'db':db,
    })
def home(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode,action='Viewed Dashboard')
    if not request.session.get('employeecode'):
        return redirect('login_view')
    total_servers = PhysicalServer.objects.count()
    total_vms = VirtualMachine.objects.count()
    total_database_servers =DatabaseServer.objects.count()
    total_softwares = Software.objects.count()
    servers = PhysicalServer.objects.all()
    vms = VirtualMachine.objects.all()
    databases =DatabaseServer.objects.all()
    softwares = Software.objects.all()

    context={
        'total_servers':total_servers,
        'total_vms':total_vms,
        'total_database_servers':total_database_servers,
        'total_softwares':total_softwares,
        'servers':servers,
        'vms':vms,
        'databases':databases,
        'softwares':softwares,
        'employeecode':request.session.get('employeecode'),
        'employeename':request.session.get('employeename'),
        'designation':request.session.get('designation'),
        'entity':request.session.get('entity'),
        'administrator':request.session.get('administrator'),

    }
    return render(request,'home.html',context)

def add_assets(request):
    servers = PhysicalServer.objects.all()
    vms = VirtualMachine.objects.all()
    softwares = Software.objects.all()
    databases = DatabaseServer.objects.all()
    apps = ApplicationServer.objects.all()
    context={
    'servers' : servers,
    'vms' : vms,
    'softwares':softwares,
    'databases':databases,
    'apps':apps,
    }

    return render(request,'add_assets.html',context)

