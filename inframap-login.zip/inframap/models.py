# inframap/models.py

from django.db import models
from django.contrib.auth.models import User
from django.db.backends.signals import connection_created
from django.dispatch import receiver


class UserProfile(models.Model):
    """
    Extended profile for every User.
    The `administrator` column controls access to asset-management features.
    """
    user          = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    administrator = models.BooleanField(default=False,
                        help_text="Grants access to Add Assets and related data-entry features.")
    role          = models.CharField(max_length=64, blank=True, default='Viewer')

    class Meta:
        db_table = 'inframap_userprofile'

    def __str__(self):
        flag = '★ Admin' if self.administrator else 'Viewer'
        return f'{self.user.username} [{flag}]'


# ── Auto-create a UserProfile whenever a new User is saved ──────────────────
from django.db.models.signals import post_save

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.get_or_create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        instance.profile.save()
