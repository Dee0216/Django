# inframap/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django import forms


# ── Login Form ───────────────────────────────────────────────────────────────

class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'placeholder': 'your.username', 'autocomplete': 'username'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': '••••••••••••', 'autocomplete': 'current-password'})
    )


# ── Views ────────────────────────────────────────────────────────────────────

def login_view(request):
    """
    Renders and processes the login page.
    After successful authentication, redirects to `next` or dashboard.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')

    form = LoginForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            next_url = request.POST.get('next') or request.GET.get('next') or 'dashboard'
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid username or password. Please try again.')

    return render(request, 'inframap/login.html', {
        'form': form,
        'next': request.GET.get('next', ''),
    })


def logout_view(request):
    """Logs the user out and redirects to the login page."""
    logout(request)
    return redirect('login')


# ── Asset Add — administrator-only ───────────────────────────────────────────

@login_required(login_url='login')
def asset_add_view(request):
    """
    The Add Assets page.  Only users whose profile.administrator == True
    may access it; everyone else gets a 403-style message and is redirected.
    """
    if not getattr(request.user.profile, 'administrator', False):
        messages.error(request, 'Access denied: Administrator privileges are required to add assets.')
        return redirect('dashboard')

    # --- your normal asset-add logic goes here ---
    return render(request, 'inframap/asset_add.html')


# ── Dashboard (example protected view) ───────────────────────────────────────

@login_required(login_url='login')
def dashboard_view(request):
    return render(request, 'inframap/dashboard.html')
