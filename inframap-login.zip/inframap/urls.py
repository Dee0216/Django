# inframap/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # ── Auth ──────────────────────────────────────────────────────────────
    path('login/',  views.login_view,  name='login'),
    path('logout/', views.logout_view, name='logout'),

    # ── Core pages ────────────────────────────────────────────────────────
    path('',          views.dashboard_view, name='dashboard'),

    # Administrator-only
    path('assets/add/', views.asset_add_view, name='asset_add'),
]
