# ─────────────────────────────────────────────────────────────────────────────
# Paste the relevant pieces below into your project's settings.py
# ─────────────────────────────────────────────────────────────────────────────

# 1. Make sure 'inframap' is in INSTALLED_APPS
INSTALLED_APPS = [
    # ... django defaults ...
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'inframap',   # <-- add this
]

# 2. Auth redirects
LOGIN_URL          = '/login/'       # where @login_required sends unauthenticated users
LOGIN_REDIRECT_URL = '/'             # default post-login destination
LOGOUT_REDIRECT_URL = '/login/'

# 3. Templates — make sure Django finds your app templates
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],                      # project-level template dirs (optional)
        'APP_DIRS': True,                # finds templates/inframap/ inside the app
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',  # needed for request.user in templates
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# 4. Static files
STATIC_URL = '/static/'
