# inframap/migrations/0001_initial.py
# Generated migration — run: python manage.py migrate

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='UserProfile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('administrator', models.BooleanField(
                    default=False,
                    help_text='Grants access to Add Assets and related data-entry features.'
                )),
                ('role', models.CharField(blank=True, default='Viewer', max_length=64)),
                ('user', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='profile',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'db_table': 'inframap_userprofile',
            },
        ),
    ]
