from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Tblempdetails


def login_view(request):
    """
    Handles GET  → show login page
    Handles POST → validate employeecode + password against tblempdetails
    """
    if request.method == 'POST':
        employeecode = request.POST.get('employeecode', '').strip()
        password     = request.POST.get('password', '').strip()

        try:
            employee = Tblempdetails.objects.get(
                employeecode=employeecode,
                password=password          # plain-text comparison (matches your schema)
            )
            # Store employee info in session
            request.session['employeecode'] = employee.employeecode
            request.session['employeename'] = employee.employeename
            request.session['designation']  = employee.designation
            request.session['section']      = employee.section
            return redirect('home')

        except Tblempdetails.DoesNotExist:
            return render(request, 'myapp/login.html', {
                'error': 'Invalid Employee Code or Password. Please try again.'
            })

    return render(request, 'myapp/login.html')


def home_view(request):
    """
    Home page – only accessible after login.
    """
    if not request.session.get('employeecode'):
        return redirect('login')

    context = {
        'employeecode': request.session.get('employeecode'),
        'employeename': request.session.get('employeename'),
        'designation' : request.session.get('designation'),
        'section'     : request.session.get('section'),
    }
    return render(request, 'myapp/home.html', context)


def logout_view(request):
    """
    Clears session and redirects to login.
    """
    request.session.flush()
    return redirect('login')
