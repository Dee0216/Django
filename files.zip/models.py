from django.db import models


class Tblempdetails(models.Model):
    """
    Maps to the existing 'tblempdetails' table in your database.
    All fields are text (CharField) including password, as per your schema.
    """
    employeecode = models.CharField(max_length=50, primary_key=True)
    employeename = models.CharField(max_length=200, db_column='employee name')
    designation  = models.CharField(max_length=200)
    section      = models.CharField(max_length=200)
    password     = models.CharField(max_length=200)

    class Meta:
        db_table = 'tblempdetails'   # exact table name in your DB
        managed  = False             # Django will NOT create/alter/drop this table

    def __str__(self):
        return f"{self.employeecode} – {self.employeename}"
