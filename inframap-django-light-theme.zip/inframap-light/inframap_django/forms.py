from django import forms
from .models import PhysicalServer, VirtualMachine, DatabaseServer, Software, ApplicationServer, SoftwareDatabaseMap


class PhysicalServerForm(forms.ModelForm):
    class Meta:
        model  = PhysicalServer
        fields = ['hostname', 'ip_address', 'cpu_model', 'ram_gb',
                  'storage_tb', 'location', 'os', 'status', 'notes']
        widgets = {
            'hostname':   forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'PROD-SRV-01'}),
            'ip_address': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '192.168.1.10'}),
            'cpu_model':  forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Intel Xeon E5-2680'}),
            'ram_gb':     forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '256'}),
            'storage_tb': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '2.0'}),
            'location':   forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'DC1 / Rack A3'}),
            'os':         forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'VMware ESXi 7.0'}),
            'status':     forms.Select(attrs={'class': 'form-select'}),
            'notes':      forms.Textarea(attrs={'class': 'form-textarea', 'placeholder': 'Additional notes...', 'rows': 3}),
        }


class VirtualMachineForm(forms.ModelForm):
    class Meta:
        model  = VirtualMachine
        fields = ['hostname', 'serverid', 'vcpu', 'ram_gb', 'ip_address', 'os', 'role', 'status']
        widgets = {
            'hostname':   forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'VM-APP-01'}),
            # serverid dropdown — label comes from PhysicalServer.__str__ which returns hostname
            'serverid':   forms.Select(attrs={'class': 'form-select'}),
            'vcpu':       forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '4'}),
            'ram_gb':     forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '16'}),
            'ip_address': forms.TextInput(attrs={'class': 'form-input', 'placeholder': '10.0.0.5'}),
            'os':         forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Ubuntu 22.04'}),
            'role':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Web Server, DB Host...'}),
            'status':     forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'serverid': 'Host Physical Server',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Show hostname in the dropdown, ordered alphabetically
        self.fields['serverid'].queryset = PhysicalServer.objects.all().order_by('hostname')
        self.fields['serverid'].empty_label = '— Select Host Server —'


class DatabaseServerForm(forms.ModelForm):
    class Meta:
        model  = DatabaseServer
        fields = ['hostname', 'vmid', 'engine', 'version', 'port',
                  'database_names', 'storage_gb', 'status']
        widgets = {
            'hostname':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'MYSQL-PROD-01'}),
            'vmid':           forms.Select(attrs={'class': 'form-select'}),
            'engine':         forms.Select(attrs={'class': 'form-select'}),
            'version':        forms.TextInput(attrs={'class': 'form-input', 'placeholder': '8.0.32'}),
            'port':           forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '3306'}),
            'database_names': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'production_db, analytics_db'}),
            'storage_gb':     forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '500'}),
            'status':         forms.Select(attrs={'class': 'form-select'}),
        }
        labels = {
            'vmid': 'Hosted On VM',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['vmid'].queryset    = VirtualMachine.objects.all().order_by('hostname')
        self.fields['vmid'].empty_label = '— Select VM (optional) —'
        self.fields['vmid'].required    = False


class SoftwareForm(forms.ModelForm):
    class Meta:
        model  = Software
        fields = ['name', 'vmid', 'category', 'version', 'license_type', 'vendor']
        widgets = {
            'name':         forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Apache Tomcat'}),
            'vmid':         forms.Select(attrs={'class': 'form-select'}),
            'category':     forms.Select(attrs={'class': 'form-select'}),
            'version':      forms.TextInput(attrs={'class': 'form-input', 'placeholder': '10.1.5'}),
            'license_type': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Open Source'}),
            'vendor':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Apache Foundation'}),
        }
        labels = {
            'vmid': 'Installed On VM',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['vmid'].queryset    = VirtualMachine.objects.all().order_by('hostname')
        self.fields['vmid'].empty_label = '— Select VM (optional) —'
        self.fields['vmid'].required    = False


class ApplicationServerForm(forms.ModelForm):
    class Meta:
        model  = ApplicationServer
        fields = ['hostname', 'vmid', 'server_type', 'version', 'port', 'deployed_apps']
        widgets = {
            'hostname':      forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'JBOSS-PROD-01'}),
            'vmid':          forms.Select(attrs={'class': 'form-select'}),
            'server_type':   forms.Select(attrs={'class': 'form-select'}),
            'version':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': '7.4.0'}),
            'port':          forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '8080'}),
            'deployed_apps': forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'billing.war, portal.ear'}),
        }
        labels = {
            'vmid': 'Hosted On VM',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['vmid'].queryset    = VirtualMachine.objects.all().order_by('hostname')
        self.fields['vmid'].empty_label = '— Select VM (optional) —'
        self.fields['vmid'].required    = False


class SoftwareDatabaseMapForm(forms.Form):
    """
    Custom form because source can be either Software or ApplicationServer.
    """
    SOURCE_CHOICES_PREFIX = []  # built dynamically in __init__

    source      = forms.ChoiceField(widget=forms.Select(attrs={'class': 'form-select'}),
                                     label='Software / App Server')
    dbserverid  = forms.ModelChoiceField(
                    queryset=DatabaseServer.objects.all().order_by('hostname'),
                    empty_label='— Select DB Server —',
                    widget=forms.Select(attrs={'class': 'form-select'}),
                    label='Database Server')
    relationship_type = forms.ChoiceField(
                    choices=[('primary','Primary'),('replica','Replica'),
                             ('readonly','Read-only'),('backup','Backup'),('staging','Staging')],
                    widget=forms.Select(attrs={'class': 'form-select'}))
    notes       = forms.CharField(required=False,
                    widget=forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'Optional notes...'}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        sw_choices = [('sw:{}'.format(s.softwareid), '[SW] {}'.format(s.name))
                      for s in Software.objects.all().order_by('name')]
        as_choices = [('as:{}'.format(a.appserverid), '[AS] {}'.format(a.hostname))
                      for a in ApplicationServer.objects.all().order_by('hostname')]
        self.fields['source'].choices = [('', '— Select Software or App Server —')] + sw_choices + as_choices
