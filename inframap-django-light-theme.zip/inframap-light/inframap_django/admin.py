from django.contrib import admin
from .models import (PhysicalServer, VirtualMachine, DatabaseServer,
                     Software, ApplicationServer, SoftwareDatabaseMap)


@admin.register(PhysicalServer)
class PhysicalServerAdmin(admin.ModelAdmin):
    list_display  = ('serverid', 'hostname', 'ip_address', 'location', 'status')
    search_fields = ('hostname', 'ip_address', 'location')
    list_filter   = ('status',)


@admin.register(VirtualMachine)
class VirtualMachineAdmin(admin.ModelAdmin):
    list_display  = ('vmid', 'hostname', 'serverid', 'ip_address', 'status')
    search_fields = ('hostname', 'ip_address')
    list_filter   = ('status', 'serverid')
    # shows PhysicalServer.hostname in the FK dropdown in admin too
    raw_id_fields = ()


@admin.register(DatabaseServer)
class DatabaseServerAdmin(admin.ModelAdmin):
    list_display  = ('dbserverid', 'hostname', 'vmid', 'engine', 'port', 'status')
    search_fields = ('hostname', 'database_names')
    list_filter   = ('engine', 'status')


@admin.register(Software)
class SoftwareAdmin(admin.ModelAdmin):
    list_display  = ('softwareid', 'name', 'vmid', 'category', 'version')
    search_fields = ('name', 'vendor')
    list_filter   = ('category',)


@admin.register(ApplicationServer)
class ApplicationServerAdmin(admin.ModelAdmin):
    list_display  = ('appserverid', 'hostname', 'vmid', 'server_type', 'port')
    search_fields = ('hostname', 'deployed_apps')
    list_filter   = ('server_type',)


@admin.register(SoftwareDatabaseMap)
class SoftwareDatabaseMapAdmin(admin.ModelAdmin):
    list_display  = ('mapid', 'source_type', 'softwareid', 'appserverid',
                     'dbserverid', 'relationship_type')
    list_filter   = ('source_type', 'relationship_type')
