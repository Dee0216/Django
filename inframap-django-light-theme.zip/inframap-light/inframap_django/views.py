from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q

from .models import (PhysicalServer, VirtualMachine, DatabaseServer,
                     Software, ApplicationServer, SoftwareDatabaseMap)
from .forms  import (PhysicalServerForm, VirtualMachineForm, DatabaseServerForm,
                     SoftwareForm, ApplicationServerForm, SoftwareDatabaseMapForm)


# ── helpers ───────────────────────────────────────────────────────────────────
def _base_context():
    """Counts injected into every page (navbar / sidebar badges)."""
    return {
        'server_count':   PhysicalServer.objects.count(),
        'vm_count':       VirtualMachine.objects.count(),
        'db_count':       DatabaseServer.objects.count(),
        'software_count': Software.objects.count() + ApplicationServer.objects.count(),
        'mapping_count':  SoftwareDatabaseMap.objects.count(),
        'asset_count':    (DatabaseServer.objects.count() +
                           Software.objects.count() +
                           ApplicationServer.objects.count()),
    }


# ── Dashboard ─────────────────────────────────────────────────────────────────
def dashboard(request):
    # prefetch VMs and their nested assets for topology rendering
    servers = PhysicalServer.objects.prefetch_related(
        'virtual_machines__db_servers',
        'virtual_machines__software',
        'virtual_machines__app_servers',
    ).all()

    ctx = _base_context()
    ctx.update({'servers': servers})
    return render(request, 'inframap/dashboard.html', ctx)


# ── Topology ──────────────────────────────────────────────────────────────────
def topology(request):
    servers = PhysicalServer.objects.prefetch_related(
        'virtual_machines__db_servers',
        'virtual_machines__software',
        'virtual_machines__app_servers',
    ).all()

    ctx = _base_context()
    ctx.update({'servers': servers})
    return render(request, 'inframap/topology.html', ctx)


# ── Add Assets ────────────────────────────────────────────────────────────────
def asset_add(request):
    """
    Renders the tabbed add-assets page.
    Each form tab POSTs to its own URL, so this view only handles GET.
    active_tab lets the template re-open the right tab after a redirect.
    """
    ctx = _base_context()
    ctx.update({
        'active_tab':    request.GET.get('tab', 'server'),
        'server_form':   PhysicalServerForm(),
        'vm_form':       VirtualMachineForm(),       # dropdown populated in form __init__
        'db_form':       DatabaseServerForm(),
        'sw_form':       SoftwareForm(),
        'as_form':       ApplicationServerForm(),
    })
    return render(request, 'inframap/asset_add.html', ctx)


# ── Add Physical Server ───────────────────────────────────────────────────────
def add_server(request):
    if request.method == 'POST':
        form = PhysicalServerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Physical Server added successfully.')
            return redirect('asset_add')
        else:
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'server',
                'server_form': form,
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add Virtual Machine ───────────────────────────────────────────────────────
def add_vm(request):
    if request.method == 'POST':
        form = VirtualMachineForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Virtual Machine added successfully.')
            return redirect('asset_add')
        else:
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'vm',
                'server_form': PhysicalServerForm(),
                'vm_form':     form,             # return invalid form with errors
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add DB Server ─────────────────────────────────────────────────────────────
def add_db_server(request):
    if request.method == 'POST':
        form = DatabaseServerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Database Server added successfully.')
            return redirect('asset_add')
        else:
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'db',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     form,
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add Software ──────────────────────────────────────────────────────────────
def add_software(request):
    if request.method == 'POST':
        form = SoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Software added successfully.')
            return redirect('asset_add')
        else:
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'software',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     form,
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add App Server ────────────────────────────────────────────────────────────
def add_app_server(request):
    if request.method == 'POST':
        form = ApplicationServerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ App Server added successfully.')
            return redirect('asset_add')
        else:
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'appserver',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     form,
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Map Relations ─────────────────────────────────────────────────────────────
def map_relations(request):
    form     = SoftwareDatabaseMapForm()
    mappings = SoftwareDatabaseMap.objects.select_related(
        'softwareid', 'appserverid', 'dbserverid'
    ).all()

    ctx = _base_context()
    ctx.update({'form': form, 'mappings': mappings})
    return render(request, 'inframap/map_relations.html', ctx)


def add_mapping(request):
    if request.method == 'POST':
        form = SoftwareDatabaseMapForm(request.POST)
        if form.is_valid():
            source    = form.cleaned_data['source']       # e.g. 'sw:3' or 'as:7'
            dbserver  = form.cleaned_data['dbserverid']
            rel_type  = form.cleaned_data['relationship_type']
            notes     = form.cleaned_data['notes']

            prefix, pk = source.split(':')
            mapping = SoftwareDatabaseMap(dbserverid=dbserver,
                                          relationship_type=rel_type,
                                          notes=notes)
            if prefix == 'sw':
                mapping.source_type = 'software'
                mapping.softwareid  = Software.objects.get(pk=pk)
            else:
                mapping.source_type = 'appserver'
                mapping.appserverid = ApplicationServer.objects.get(pk=pk)
            mapping.save()
            messages.success(request, '✅ Mapping created successfully.')
        else:
            messages.error(request, '⚠️ Please select both fields.')
    return redirect('map_relations')


def delete_mapping(request, pk):
    mapping = get_object_or_404(SoftwareDatabaseMap, pk=pk)
    mapping.delete()
    messages.success(request, '🗑️ Mapping deleted.')
    return redirect('map_relations')


# ── Physical Servers List ─────────────────────────────────────────────────────
def servers_list(request):
    q       = request.GET.get('q', '')
    servers = PhysicalServer.objects.prefetch_related('virtual_machines').all()
    if q:
        servers = servers.filter(
            Q(hostname__icontains=q) |
            Q(ip_address__icontains=q) |
            Q(location__icontains=q) |
            Q(os__icontains=q)
        )
    ctx = _base_context()
    ctx.update({'servers': servers, 'q': q})
    return render(request, 'inframap/servers_list.html', ctx)


def server_detail(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    vms    = server.virtual_machines.prefetch_related('db_servers','software','app_servers').all()
    ctx = _base_context()
    ctx.update({'server': server, 'vms': vms})
    return render(request, 'inframap/server_detail.html', ctx)


def server_edit(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    if request.method == 'POST':
        form = PhysicalServerForm(request.POST, instance=server)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ Server updated.')
            return redirect('servers_list')
    else:
        form = PhysicalServerForm(instance=server)
    ctx = _base_context()
    ctx.update({'form': form, 'server': server})
    return render(request, 'inframap/server_edit.html', ctx)


def server_delete(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    server.delete()
    messages.success(request, '🗑️ Server deleted.')
    return redirect('servers_list')


# ── VMs List ──────────────────────────────────────────────────────────────────
def vms_list(request):
    q   = request.GET.get('q', '')
    vms = VirtualMachine.objects.select_related('serverid').all()
    if q:
        vms = vms.filter(
            Q(hostname__icontains=q) |
            Q(ip_address__icontains=q) |
            Q(role__icontains=q) |
            Q(serverid__hostname__icontains=q)
        )
    ctx = _base_context()
    ctx.update({'vms': vms, 'q': q})
    return render(request, 'inframap/vms_list.html', ctx)


def vm_edit(request, pk):
    vm = get_object_or_404(VirtualMachine, pk=pk)
    if request.method == 'POST':
        form = VirtualMachineForm(request.POST, instance=vm)
        if form.is_valid():
            form.save()
            messages.success(request, '✅ VM updated.')
            return redirect('vms_list')
    else:
        form = VirtualMachineForm(instance=vm)
    ctx = _base_context()
    ctx.update({'form': form, 'vm': vm})
    return render(request, 'inframap/vm_edit.html', ctx)


def vm_delete(request, pk):
    vm = get_object_or_404(VirtualMachine, pk=pk)
    vm.delete()
    messages.success(request, '🗑️ VM deleted.')
    return redirect('vms_list')


# ── Software List ─────────────────────────────────────────────────────────────
def software_list(request):
    software    = Software.objects.select_related('vmid').all()
    db_servers  = DatabaseServer.objects.select_related('vmid').all()
    app_servers = ApplicationServer.objects.select_related('vmid').all()

    ctx = _base_context()
    ctx.update({
        'software':    software,
        'db_servers':  db_servers,
        'app_servers': app_servers,
    })
    return render(request, 'inframap/software_list.html', ctx)


# ── Export JSON ───────────────────────────────────────────────────────────────
import json
from django.http import JsonResponse

def export_json(request):
    data = {
        'physical_servers': list(PhysicalServer.objects.values()),
        'virtual_machines': list(VirtualMachine.objects.values()),
        'database_servers': list(DatabaseServer.objects.values()),
        'software':         list(Software.objects.values()),
        'app_servers':      list(ApplicationServer.objects.values()),
        'mappings':         list(SoftwareDatabaseMap.objects.values()),
    }
    response = JsonResponse(data, json_dumps_params={'indent': 2})
    response['Content-Disposition'] = 'attachment; filename="inframap-export.json"'
    return response
