from django.db import models


class PhysicalServer(models.Model):
    serverid   = models.AutoField(primary_key=True)
    hostname   = models.CharField(max_length=255)
    ip_address = models.CharField(max_length=50, blank=True, null=True)
    cpu_model  = models.CharField(max_length=255, blank=True, null=True)
    ram_gb     = models.IntegerField(blank=True, null=True)
    storage_tb = models.CharField(max_length=50, blank=True, null=True)
    location   = models.CharField(max_length=255, blank=True, null=True)
    os         = models.CharField(max_length=255, blank=True, null=True)
    status     = models.CharField(max_length=50, default='online',
                                  choices=[('online','Online'),('offline','Offline'),('maintenance','Maintenance')])
    notes      = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'physical_server'

    def __str__(self):
        return self.hostname


class VirtualMachine(models.Model):
    vmid      = models.AutoField(primary_key=True)
    hostname  = models.CharField(max_length=255)
    serverid  = models.ForeignKey(PhysicalServer, on_delete=models.CASCADE,
                                   db_column='serverid', related_name='virtual_machines')
    vcpu      = models.IntegerField(blank=True, null=True)
    ram_gb    = models.IntegerField(blank=True, null=True)
    ip_address= models.CharField(max_length=50, blank=True, null=True)
    os        = models.CharField(max_length=255, blank=True, null=True)
    role      = models.CharField(max_length=255, blank=True, null=True)
    status    = models.CharField(max_length=50, default='online',
                                  choices=[('online','Running'),('offline','Stopped'),('maintenance','Suspended')])

    class Meta:
        db_table = 'virtual_machine'

    def __str__(self):
        return self.hostname


class DatabaseServer(models.Model):
    dbserverid     = models.AutoField(primary_key=True)
    hostname       = models.CharField(max_length=255)
    vmid           = models.ForeignKey(VirtualMachine, on_delete=models.SET_NULL,
                                        null=True, blank=True, db_column='vmid',
                                        related_name='db_servers')
    engine         = models.CharField(max_length=100,
                                       choices=[('MySQL','MySQL'),('PostgreSQL','PostgreSQL'),
                                                ('Oracle','Oracle'),('MSSQL','MS SQL Server'),
                                                ('MongoDB','MongoDB'),('Redis','Redis'),
                                                ('MariaDB','MariaDB'),('Other','Other')])
    version        = models.CharField(max_length=50, blank=True, null=True)
    port           = models.IntegerField(blank=True, null=True)
    database_names = models.CharField(max_length=500, blank=True, null=True)
    storage_gb     = models.IntegerField(blank=True, null=True)
    status         = models.CharField(max_length=50, default='online',
                                       choices=[('online','Active'),('offline','Down'),('maintenance','Maintenance')])

    class Meta:
        db_table = 'database_server'

    def __str__(self):
        return self.hostname


class Software(models.Model):
    softwareid   = models.AutoField(primary_key=True)
    name         = models.CharField(max_length=255)
    vmid         = models.ForeignKey(VirtualMachine, on_delete=models.SET_NULL,
                                      null=True, blank=True, db_column='vmid',
                                      related_name='software')
    category     = models.CharField(max_length=100,
                                     choices=[('Web Server','Web Server'),('App Server','App Server'),
                                              ('Middleware','Middleware'),('Monitoring','Monitoring'),
                                              ('Security','Security'),('Backup','Backup'),
                                              ('Development','Development'),('Other','Other')])
    version      = models.CharField(max_length=50, blank=True, null=True)
    license_type = models.CharField(max_length=100, blank=True, null=True)
    vendor       = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'software'

    def __str__(self):
        return self.name


class ApplicationServer(models.Model):
    appserverid   = models.AutoField(primary_key=True)
    hostname      = models.CharField(max_length=255)
    vmid          = models.ForeignKey(VirtualMachine, on_delete=models.SET_NULL,
                                       null=True, blank=True, db_column='vmid',
                                       related_name='app_servers')
    server_type   = models.CharField(max_length=100,
                                      choices=[('JBoss / WildFly','JBoss / WildFly'),
                                               ('WebLogic','WebLogic'),('WebSphere','WebSphere'),
                                               ('Tomcat','Tomcat'),('IIS','IIS'),
                                               ('Node.js','Node.js'),('Nginx','Nginx'),
                                               ('Apache','Apache'),('Other','Other')])
    version       = models.CharField(max_length=50, blank=True, null=True)
    port          = models.IntegerField(blank=True, null=True)
    deployed_apps = models.CharField(max_length=500, blank=True, null=True)

    class Meta:
        db_table = 'application_server'

    def __str__(self):
        return self.hostname


class SoftwareDatabaseMap(models.Model):
    mapid             = models.AutoField(primary_key=True)
    # source can be software or app server — store type + id
    source_type       = models.CharField(max_length=20,
                                          choices=[('software','Software'),('appserver','App Server')])
    softwareid        = models.ForeignKey(Software, on_delete=models.CASCADE,
                                           null=True, blank=True, db_column='softwareid')
    appserverid       = models.ForeignKey(ApplicationServer, on_delete=models.CASCADE,
                                           null=True, blank=True, db_column='appserverid')
    dbserverid        = models.ForeignKey(DatabaseServer, on_delete=models.CASCADE,
                                           db_column='dbserverid', related_name='mappings')
    relationship_type = models.CharField(max_length=50,
                                          choices=[('primary','Primary'),('replica','Replica'),
                                                   ('readonly','Read-only'),('backup','Backup'),
                                                   ('staging','Staging')])
    notes             = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'software_database_map'

    def __str__(self):
        return f"Map {self.mapid}"
