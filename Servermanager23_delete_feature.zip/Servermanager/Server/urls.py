from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('', views.login_view, name='login_view'),
    path('logout/', views.logout_view, name='logout'),

    # Dashboard & Assets
    path('home/', views.home, name='home'),
    path('add_assets/', views.add_assets, name='add_assets'),

    # Physical Server
    path('add-server/', views.add_physical_server, name='add_physical_server'),
    path('list-servers/', views.list_physical_servers, name='list_physical_servers'),
    path('server/edit/<int:server_id>/', views.edit_physicalserver, name='edit_physicalserver'),
    path('servers/<int:server_id>/servers/', views.physical_server_def, name='physical_server_def'),
    path('servers/<int:server_id>/vms/', views.vms_by_server, name='vms_by_server'),
    path('servers/<int:server_id>/vms-preview/', views.vms_preview, name='vms_preview'),

    # Virtual Machine
    path('add-vm/', views.add_virtual_machine, name='add_virtual_machine'),
    path('list-vms/', views.list_virtual_machine, name='list_virtual_machine'),
    path('vm/edit/<int:vm_id>/', views.edit_vm, name='edit_vm'),
    path('vm/<int:vm_id>/vm/', views.virtual_machine_def, name='virtual_machine_def'),
    path('vm/<int:vm_id>/softwares/', views.softwares_by_vm, name='softwares_by_vm'),
    path('vm/<int:vm_id>/databases/', views.databases_by_vm, name='databases_by_vm'),
    path('vm/<int:vm_id>/schemas/', views.schemas_by_vm, name='schemas_by_vm'),
    path('vms/<int:vm_id>/dbs-preview/', views.dbs_preview, name='dbs_preview'),
    path('vms/<int:vm_id>/software-preview/', views.software_preview, name='software_preview'),

    # Application Server
    path('add-application-server/', views.add_application_server, name='add_application_server'),
    path('list-app/', views.list_application_server, name='list_application_server'),
    path('app/edit/<int:app_id>/', views.edit_applications, name='edit_applications'),

    # NEW DatabaseServer (logical DB server on a VM)
    path('add-dbservers/', views.add_database_server, name='add_database_server'),
    path('list-dbservers/', views.list_database_server, name='list_database_server'),
    path('dbserver/edit/<int:db_id>/', views.edit_database_server, name='edit_database_server'),
    path('dbserver/<int:db_id>/', views.database_server_def, name='database_server_def'),

    # SchemaInfo (renamed from old DatabaseServer)
    path('add-schema/', views.add_schema_info, name='add_schema_info'),
    path('list-schema/', views.list_schema_info, name='list_schema_info'),
    path('schema/edit/<int:db_id>/', views.edit_schema_info, name='edit_schema_info'),
    path('schema/<int:db_id>/', views.schema_info_def, name='schema_info_def'),
    # Legacy alias so old links to database_def still work
    path('database/<int:db_id>/', views.database_def, name='database_def'),

    # Software
    path('add-software/', views.add_software_server, name='add_software_server'),
    path('list-software/', views.list_software_server, name='list_software_server'),
    path('software/edit/<int:software_id>/', views.edit_software, name='edit_software'),
    path('software/<int:software_id>/', views.software_def, name='software_def'),

    # Mapping
    path('map/', views.software_db_map, name='software_db_map'),
    path('mappings/', views.software_db_map_list, name='software_db_map_list'),

    # Legacy URL kept for backward compat
    path('vm/<int:vm_id>/vms/', views.databases_by_vm, name='databases_by_vm_legacy'),

    # ── Check-children JSON endpoints (used by delete modal) ──
    path('server/<int:server_id>/check-children/', views.check_server_children, name='check_server_children'),
    path('vm/<int:vm_id>/check-children/', views.check_vm_children, name='check_vm_children'),
    path('app/<int:app_id>/check-children/', views.check_app_children, name='check_app_children'),
    path('dbserver/<int:db_id>/check-children/', views.check_dbserver_children, name='check_dbserver_children'),

    # ── Delete endpoints (POST only) ──
    path('server/delete/<int:server_id>/', views.delete_physical_server, name='delete_physical_server'),
    path('vm/delete/<int:vm_id>/', views.delete_virtual_machine, name='delete_virtual_machine'),
    path('app/delete/<int:app_id>/', views.delete_application_server, name='delete_application_server'),
    path('dbserver/delete/<int:db_id>/', views.delete_database_server, name='delete_database_server'),
    path('schema/delete/<int:db_id>/', views.delete_schema_info, name='delete_schema_info'),
    path('software/delete/<int:software_id>/', views.delete_software, name='delete_software'),
]
