from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from django.contrib import messages
from .forms import (PhysicalServerForm, VirtualMachineForm, DatabaseServerForm,
                    SchemaInfoForm, SoftwareForm, SoftwareDatabaseMapForm,
                    TblEmpdetailsForm, ApplicationServerForm)
from .models import (PhysicalServer, VirtualMachine, DatabaseServer, SchemaInfo,
                     Software, SoftwareDatabaseMap, TblEmpdetails, AuthLog, ApplicationServer)


# ──────────────────────────────────────────────────────────────
# Auth
# ──────────────────────────────────────────────────────────────

def login_view(request):
    if request.method == 'POST':
        employeecode = request.POST.get('employeecode', '').strip()
        password = request.POST.get('password', '').strip()
        try:
            employee = TblEmpdetails.objects.get(employeecode=employeecode, password=password)
            request.session['employeecode'] = employee.employeecode
            request.session['employeename'] = employee.employeename
            request.session['designation'] = employee.designation
            request.session['entity'] = employee.entity
            request.session['administrator'] = employee.administrator
            AuthLog.objects.create(username=employee.employeecode, action='login')
            return redirect('home')
        except TblEmpdetails.DoesNotExist:
            AuthLog.objects.create(username='employeecode', action='failed')
            return render(request, 'login.html', {'error': "Invalid Employee code or Password. Please try again."})
    return render(request, 'login.html')


def logout_view(request):
    AuthLog.objects.create(username=request.session.get('employeecode', 'Unknown'), action='logout')
    request.session.flush()
    return redirect('login_view')


# ──────────────────────────────────────────────────────────────
# Physical Server
# ──────────────────────────────────────────────────────────────

def add_physical_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Added Physical server')
    if request.method == "POST":
        form = PhysicalServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = PhysicalServerForm()
    return render(request, 'add_assets.html', {'form': form})


def list_physical_servers(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed Physical server')
    servers = PhysicalServer.objects.filter(is_delete=0)
    return render(request, 'list_physical_servers.html', {'servers': servers})


def edit_physicalserver(request, server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    server = get_object_or_404(PhysicalServer, pk=server_id)
    AuthLog.objects.create(username=employeecode, action='viewed_edit_server',
                           details=f"Opened edit for Server ID {server_id} ({server.hostname})")
    if request.method == 'POST':
        before = {
            'hostname': server.hostname, 'user_id': server.user_id, 'password': server.password,
            'make': server.make, 'ip_address': server.ip_address, 'model': server.model,
            'service_tag': server.service_tag, 'purchase_no': server.purchase_no,
            'purchase_date': str(server.purchase_date), 'warranty_expiry': str(server.warranty_expiry),
            'location': server.location, 'notes': server.notes,
        }
        server.hostname = request.POST.get('hostname')
        server.user_id = request.POST.get('user_id')
        server.password = request.POST.get('password')
        server.make = request.POST.get('make')
        server.ip_address = request.POST.get('ip_address')
        server.model = request.POST.get('model')
        server.service_tag = request.POST.get('service_tag')
        server.purchase_no = request.POST.get('purchase_no')
        server.purchase_date = request.POST.get('purchase_date') or None
        server.warranty_expiry = request.POST.get('warranty_expiry') or None
        server.location = request.POST.get('location')
        server.notes = request.POST.get('notes')
        server.save()
        after = {
            'hostname': server.hostname, 'user_id': server.user_id, 'password': server.password,
            'make': server.make, 'ip_address': server.ip_address, 'model': server.model,
            'service_tag': server.service_tag, 'purchase_no': server.purchase_no,
            'purchase_date': str(server.purchase_date), 'warranty_expiry': str(server.warranty_expiry),
            'location': server.location, 'notes': server.notes,
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_server',
                               details=f"Server ID {server_id} | Changes: {changes}")
        return redirect('list_physical_servers')
    return render(request, 'edit_physicalserver.html', {'server': server})


# ──────────────────────────────────────────────────────────────
# Virtual Machine
# ──────────────────────────────────────────────────────────────

def add_virtual_machine(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action="Added VM")
    if request.method == "POST":
        form = VirtualMachineForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = VirtualMachineForm()
    return render(request, 'add_assets.html', {'form': form})


def list_virtual_machine(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed VM list')
    vms = VirtualMachine.objects.select_related('physical_server').filter(is_delete=0)
    return render(request, 'list_virtual_machine.html', {'vms': vms})


def edit_vm(request, vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    AuthLog.objects.create(username=employeecode, action='viewed_edit_vm',
                           details=f"Opened edit for VM ID {vm_id} ({vm.hostname})")
    before = {
        'hostname': vm.hostname, 'user_id': vm.user_id, 'password': vm.password,
        'os': vm.os, 'cpu_core': str(vm.cpu_cores), 'ram': str(vm.ram_gb),
        'storage': str(vm.storage_gb), 'ip_address': vm.ip_address,
        'description': vm.description, 'server_id': str(vm.physical_server_id),
    }
    if request.method == 'POST':
        vm.hostname = request.POST.get('hostname')
        vm.user_id = request.POST.get('user_id')
        vm.password = request.POST.get('password')
        vm.os = request.POST.get('os')
        vm.cpu_cores = request.POST.get('cpu_cores')
        vm.ram_gb = request.POST.get('ram_gb')
        vm.storage_gb = request.POST.get('storage_gb')
        vm.ip_address = request.POST.get('ip_address')
        vm.description = request.POST.get('description')
        server_id = request.POST.get('physical_server_id')
        if server_id:
            vm.physical_server_id = server_id
        vm.save()
        after = {
            'hostname': vm.hostname, 'user_id': vm.user_id, 'password': vm.password,
            'os': vm.os, 'cpu_core': str(vm.cpu_cores), 'ram': str(vm.ram_gb),
            'storage': str(vm.storage_gb), 'ip_address': vm.ip_address,
            'description': vm.description, 'server_id': str(vm.physical_server_id),
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_vm',
                               details=f"VM ID {vm_id} | Changes: {changes}")
        return redirect('list_virtual_machine')
    servers = PhysicalServer.objects.filter(is_delete=0)
    return render(request, 'edit_vm.html', {'vm': vm, 'servers': servers})


# ──────────────────────────────────────────────────────────────
# Application Server
# ──────────────────────────────────────────────────────────────

def add_application_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    if request.method == "POST":
        form = ApplicationServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = ApplicationServerForm()
    return render(request, 'add_assets.html', {'form': form})


def list_application_server(request):
    employeecode = request.session.get('employeecode')
    apps = ApplicationServer.objects.select_related('vm').filter(is_delete=0)
    return render(request, 'list_application_server.html', {'apps': apps})


def edit_applications(request, app_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    app = get_object_or_404(ApplicationServer, pk=app_id)
    if request.method == "POST":
        before = {
            'app_name': app.name, 'user_id': app.userid, 'password': app.password,
            'location': app.location, 'focal_point': app.focal_point,
            'remarks': app.remarks, 'vm_id': str(app.vm_id),
        }
        app.name = request.POST.get('name')
        app.userid = request.POST.get('userid')
        app.password = request.POST.get('password')
        app.location = request.POST.get('location')
        app.focal_point = request.POST.get('focal_point')
        app.remarks = request.POST.get('remarks')
        vm_id = request.POST.get('vm')
        if vm_id:
            app.vm_id = vm_id
        app.save()
        after = {
            'app_name': app.name, 'user_id': app.userid, 'password': app.password,
            'location': app.location, 'focal_point': app.focal_point,
            'remarks': app.remarks, 'vm_id': str(app.vm_id),
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_database',
                               details=f"App ID {app_id} | Changes: {changes}")
        return redirect('list_application_server')
    vms = VirtualMachine.objects.filter(is_delete=0)
    return render(request, 'edit_applications.html', {'app': app, 'vms': vms})


# ──────────────────────────────────────────────────────────────
# NEW DatabaseServer (logical DB server on a VM)
# ──────────────────────────────────────────────────────────────

def add_database_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Added DatabaseServer')
    if request.method == "POST":
        form = DatabaseServerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = DatabaseServerForm()
    return render(request, 'add_assets.html', {'form': form})


def list_database_server(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed DatabaseServer')
    db_servers = DatabaseServer.objects.select_related('vm').filter(is_delete=0)
    return render(request, 'list_database_server.html', {'db_servers': db_servers})


def edit_database_server(request, db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    db_server = get_object_or_404(DatabaseServer, pk=db_id)
    AuthLog.objects.create(username=employeecode, action='viewed_edit_database_server',
                           details=f"Opened edit for Database Server ID {db_id} ({db_server.name})")
    if request.method == "POST":
        before = {
            'name': db_server.name, 'focal_point': db_server.focal_point,
            'location': db_server.location, 'port': str(db_server.port),
            'remarks': db_server.remarks, 'vm_id': str(db_server.vm_id),
        }
        db_server.name = request.POST.get('name')
        db_server.focal_point = request.POST.get('focal_point')
        db_server.location = request.POST.get('location')
        db_server.port = request.POST.get('port') or None
        db_server.remarks = request.POST.get('remarks')
        vm_id = request.POST.get('vm')
        if vm_id:
            db_server.vm_id = vm_id
        db_server.save()
        after = {
            'name': db_server.name, 'focal_point': db_server.focal_point,
            'location': db_server.location, 'port': str(db_server.port),
            'remarks': db_server.remarks, 'vm_id': str(db_server.vm_id),
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_database_server',
                               details=f"DB Server ID {db_id} | Changes: {changes}")
        return redirect('list_database_server')
    vms = VirtualMachine.objects.filter(is_delete=0)
    return render(request, 'edit_database_server.html', {'db_server': db_server, 'vms': vms})


def database_server_def(request, db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    db_server = get_object_or_404(DatabaseServer, pk=db_id)
    schemas = SchemaInfo.objects.filter(database_server=db_server, is_delete=0)
    return render(request, 'database_server_def.html', {'db_server': db_server, 'schemas': schemas})


# ──────────────────────────────────────────────────────────────
# SchemaInfo (renamed from old DatabaseServer)
# ──────────────────────────────────────────────────────────────

def add_schema_info(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Added database')
    if request.method == "POST":
        form = SchemaInfoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = SchemaInfoForm()
    return render(request, 'add_assets.html', {'form': form})


def list_schema_info(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed Database')
    schemas = SchemaInfo.objects.select_related('database_server__vm').filter(is_delete=0)
    return render(request, 'list_schema_info.html', {'schemas': schemas})


def edit_schema_info(request, db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    schema = get_object_or_404(SchemaInfo, pk=db_id)
    AuthLog.objects.create(username=employeecode, action='viewed_edit_schema_info',
                           details=f"Opened edit for Schema Info ID {db_id} ({schema.db_name})")
    if request.method == "POST":
        before = {
            'db_type': schema.db_type, 'user_id': schema.user_id, 'password': schema.password,
            'version': schema.version, 'port': str(schema.port),
            'description': schema.description, 'db_name': schema.db_name,
            'database_server_id': str(schema.database_server_id),
        }
        schema.db_type = request.POST.get('db_type')
        schema.user_id = request.POST.get('user_id')
        schema.password = request.POST.get('password')
        schema.version = request.POST.get('version')
        schema.port = request.POST.get('port') or None
        schema.description = request.POST.get('description')
        schema.db_name = request.POST.get('db_name')
        database_server_id = request.POST.get('database_server')
        if database_server_id:
            schema.database_server_id = database_server_id
        schema.save()
        after = {
            'db_type': schema.db_type, 'user_id': schema.user_id, 'password': schema.password,
            'version': schema.version, 'port': str(schema.port),
            'description': schema.description, 'db_name': schema.db_name,
            'database_server_id': str(schema.database_server_id),
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_schema_info',
                               details=f"Schema Info ID {db_id} | Changes: {changes}")
        return redirect('list_schema_info')
    db_servers = DatabaseServer.objects.select_related('vm').filter(is_delete=0)
    return render(request, 'edit_schema_info.html', {'schema': schema, 'db_servers': db_servers})


def schema_info_def(request, db_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    schema = get_object_or_404(SchemaInfo, pk=db_id)
    return render(request, 'schema_info_def.html', {'schema': schema})


# ──────────────────────────────────────────────────────────────
# Software
# ──────────────────────────────────────────────────────────────

def add_software_server(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Added software')
    if request.method == "POST":
        form = SoftwareForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = SoftwareForm()
    return render(request, 'add_assets.html', {'form': form})


def list_software_server(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed Software')
    softwares = Software.objects.select_related('app__vm').filter(is_delete=0)
    return render(request, 'list_software_server.html', {'softwares': softwares})


def edit_software(request, software_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    software = get_object_or_404(Software, pk=software_id)
    AuthLog.objects.create(username=employeecode, action='viewed_edit_Software',
                           details=f"Opened edit for Software ID {software_id} ({software.name})")
    if request.method == "POST":
        before = {
            'name': software.name, 'version': software.version, 'client': software.client,
            'focal_point': software.focal_point, 'programming_language': software.programming_language,
            'description': software.description, 'app_id': str(software.app_id),
        }
        software.name = request.POST.get('name')
        software.version = request.POST.get('version')
        software.client = request.POST.get('client')
        software.focal_point = request.POST.get('focal_point')
        software.programming_language = request.POST.get('programming_language')
        software.description = request.POST.get('description')
        app_id = request.POST.get('app')
        if app_id:
            software.app_id = app_id
        software.save()
        after = {
            'name': software.name, 'version': software.version, 'client': software.client,
            'focal_point': software.focal_point, 'programming_language': software.programming_language,
            'description': software.description, 'app_id': str(software.app_id),
        }
        changes = {f: {'before': before[f], 'after': after[f]} for f in before if before[f] != after[f]}
        AuthLog.objects.create(username=employeecode, action='edited_software',
                               details=f"Software ID {software_id} | Changes: {changes}")
        return redirect('list_software_server')
    apps = ApplicationServer.objects.select_related('vm').filter(is_delete=0)
    return render(request, 'edit_software.html', {'software': software, 'apps': apps})


def software_def(request, software_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    software = get_object_or_404(Software, pk=software_id)
    return render(request, 'software_def.html', {'software': software})


# ──────────────────────────────────────────────────────────────
# Software-Database Mapping
# ──────────────────────────────────────────────────────────────

def software_db_map(request):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action="Added Mappings")
    if request.method == "POST":
        form = SoftwareDatabaseMapForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_assets')
    else:
        form = SoftwareDatabaseMapForm()
    return render(request, 'add_assets.html', {'form': form})


def software_db_map_list(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed Mapping')
    if not request.session.get("employeecode"):
        return redirect('login_view')
    mappings = SoftwareDatabaseMap.objects.select_related('software', 'db').filter(is_delete=0)
    return render(request, "software_db_map_list.html", {'mappings': mappings})


# ──────────────────────────────────────────────────────────────
# Drill-down views
# ──────────────────────────────────────────────────────────────

def vms_by_server(request, server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    server = get_object_or_404(PhysicalServer, pk=server_id)
    vms = VirtualMachine.objects.filter(physical_server=server, is_delete=0)
    return render(request, 'vms_by_server.html', {'server': server, 'vms': vms})


def softwares_by_vm(request, vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    # Double join: Software -> ApplicationServer -> VirtualMachine
    softwares = Software.objects.select_related('app__vm').filter(app__vm=vm, is_delete=0)
    return render(request, 'softwares_by_vm.html', {'vm': vm, 'softwares': softwares})


def schemas_by_vm(request, vm_id):
    """Show all SchemaInfo records for a VM using double join: SchemaInfo -> DatabaseServer -> VM"""
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    # Double join: SchemaInfo -> DatabaseServer -> VirtualMachine
    schemas = SchemaInfo.objects.select_related('database_server__vm').filter(database_server__vm=vm, is_delete=0)
    return render(request, 'schemas_by_vm.html', {'vm': vm, 'schemas': schemas})


def databases_by_vm(request, vm_id):
    """Show all DatabaseServer records for a VM (direct FK)."""
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    db_servers = DatabaseServer.objects.filter(vm=vm, is_delete=0)
    return render(request, 'databases_by_vm.html', {'vm': vm, 'db_servers': db_servers})


# ──────────────────────────────────────────────────────────────
# JSON preview endpoints
# ──────────────────────────────────────────────────────────────

def vms_preview(request, server_id):
    vms = VirtualMachine.objects.filter(physical_server_id=server_id, is_delete=0).values_list('hostname', flat=True)
    return JsonResponse({'vms': list(vms)})


def dbs_preview(request, vm_id):
    # Show DatabaseServer names for a VM (direct FK)
    dbs = DatabaseServer.objects.filter(vm_id=vm_id, is_delete=0).values_list('name', flat=True)
    return JsonResponse({'dbs': list(dbs)})


def software_preview(request, vm_id):
    softwares = Software.objects.filter(app__vm_id=vm_id, is_delete=0).values_list('name', flat=True)
    return JsonResponse({'softwares': list(softwares)})


# ──────────────────────────────────────────────────────────────
# Detail views
# ──────────────────────────────────────────────────────────────

def physical_server_def(request, server_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    server = get_object_or_404(PhysicalServer, pk=server_id)
    return render(request, 'physical_server_def.html', {'server': server})


def virtual_machine_def(request, vm_id):
    if not request.session.get('employeecode'):
        return redirect('login_view')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    return render(request, 'virtual_machine_def.html', {'vm': vm})


# Kept as alias so old URL 'database_def' still resolves to schema_info_def
def database_def(request, db_id):
    return schema_info_def(request, db_id)


# ──────────────────────────────────────────────────────────────
# Dashboard & Assets
# ──────────────────────────────────────────────────────────────

def home(request):
    employeecode = request.session.get('employeecode')
    AuthLog.objects.create(username=employeecode, action='Viewed Dashboard')
    if not request.session.get('employeecode'):
        return redirect('login_view')
    context = {
        'total_servers': PhysicalServer.objects.filter(is_delete=0).count(),
        'total_vms': VirtualMachine.objects.filter(is_delete=0).count(),
        'total_database_servers': DatabaseServer.objects.filter(is_delete=0).count(),
        'total_softwares': Software.objects.filter(is_delete=0).count(),
        'servers': PhysicalServer.objects.filter(is_delete=0),
        'vms': VirtualMachine.objects.filter(is_delete=0),
        'databases': DatabaseServer.objects.select_related('vm').filter(is_delete=0),
        'softwares': Software.objects.filter(is_delete=0),
        'employeecode': request.session.get('employeecode'),
        'employeename': request.session.get('employeename'),
        'designation': request.session.get('designation'),
        'entity': request.session.get('entity'),
        'administrator': request.session.get('administrator'),
    }
    return render(request, 'home.html', context)


def add_assets(request):
    context = {
        'servers': PhysicalServer.objects.filter(is_delete=0),
        'vms': VirtualMachine.objects.filter(is_delete=0),
        'softwares': Software.objects.filter(is_delete=0),
        'databases': DatabaseServer.objects.filter(is_delete=0),
        'schemas': SchemaInfo.objects.filter(is_delete=0),
        'apps': ApplicationServer.objects.filter(is_delete=0),
    }
    return render(request, 'add_assets.html', context)



# ──────────────────────────────────────────────────────────────
# SOFT DELETE — CASCADE HELPERS
#
# Deleting sets is_delete=1 on the target row and all rows that
# depend on it through the hierarchy:
#
#   PhysicalServer
#     └─ VirtualMachine
#          ├─ ApplicationServer
#          │    └─ Software
#          │         └─ SoftwareDatabaseMap
#          └─ DatabaseServer
#               └─ SchemaInfo
#                    └─ SoftwareDatabaseMap
# ──────────────────────────────────────────────────────────────

def _soft_delete_vm(vm_id):
    """Soft-delete a VM and all children: AppServers, Software, DBServers, SchemaInfo, Maps."""
    # App servers + their software + maps
    app_ids = list(ApplicationServer.objects.filter(vm_id=vm_id).values_list('app_id', flat=True))
    if app_ids:
        sw_ids = list(Software.objects.filter(app_id__in=app_ids).values_list('software_id', flat=True))
        if sw_ids:
            SoftwareDatabaseMap.objects.filter(software_id__in=sw_ids).update(is_delete=1)
        Software.objects.filter(app_id__in=app_ids).update(is_delete=1)
    ApplicationServer.objects.filter(vm_id=vm_id).update(is_delete=1)

    # DB servers + their schemas + maps
    db_ids = list(DatabaseServer.objects.filter(vm_id=vm_id).values_list('db_id', flat=True))
    if db_ids:
        schema_ids = list(SchemaInfo.objects.filter(database_server_id__in=db_ids)
                          .values_list('db_id', flat=True))
        if schema_ids:
            SoftwareDatabaseMap.objects.filter(db_id__in=schema_ids).update(is_delete=1)
        SchemaInfo.objects.filter(database_server_id__in=db_ids).update(is_delete=1)
    DatabaseServer.objects.filter(vm_id=vm_id).update(is_delete=1)

    VirtualMachine.objects.filter(vm_id=vm_id).update(is_delete=1)


# ── Check-children JSON endpoints ────────────────────────────
# These only look at active (is_delete=0) children.

def check_server_children(request, server_id):
    names = list(VirtualMachine.objects.filter(physical_server_id=server_id, is_delete=0)
                 .values_list('hostname', flat=True))
    return JsonResponse({'count': len(names), 'children': names})


def check_vm_children(request, vm_id):
    apps = list(ApplicationServer.objects.filter(vm_id=vm_id, is_delete=0)
                .values_list('name', flat=True))
    dbs  = list(DatabaseServer.objects.filter(vm_id=vm_id, is_delete=0)
                .values_list('name', flat=True))
    children = apps + dbs
    return JsonResponse({'count': len(children), 'children': children, 'apps': apps, 'dbs': dbs})


def check_app_children(request, app_id):
    softwares = list(Software.objects.filter(app_id=app_id, is_delete=0)
                     .values_list('name', flat=True))
    return JsonResponse({'count': len(softwares), 'children': softwares})


def check_dbserver_children(request, db_id):
    schemas = list(SchemaInfo.objects.filter(database_server_id=db_id, is_delete=0)
                   .values_list('db_name', flat=True))
    return JsonResponse({'count': len(schemas), 'children': schemas})


# ── Soft-delete views ─────────────────────────────────────────

def delete_physical_server(request, server_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_physical_servers')
    server = get_object_or_404(PhysicalServer, pk=server_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        # Cascade: soft-delete all VMs and their children
        vm_ids = list(VirtualMachine.objects.filter(physical_server_id=server_id, is_delete=0)
                      .values_list('vm_id', flat=True))
        for vm_id in vm_ids:
            _soft_delete_vm(vm_id)
        server.is_delete = 1
        server.save()
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted Physical Server ID {server_id} ({server.hostname}) "
                    f"and {len(vm_ids)} linked VM(s)"
        )
    return redirect('list_physical_servers')


def delete_virtual_machine(request, vm_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_virtual_machine')
    vm = get_object_or_404(VirtualMachine, pk=vm_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        _soft_delete_vm(vm_id)
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted VM ID {vm_id} ({vm.hostname}) and all linked records"
        )
    return redirect('list_virtual_machine')


def delete_application_server(request, app_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_application_server')
    app = get_object_or_404(ApplicationServer, pk=app_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        sw_ids = list(Software.objects.filter(app_id=app_id)
                      .values_list('software_id', flat=True))
        if sw_ids:
            SoftwareDatabaseMap.objects.filter(software_id__in=sw_ids).update(is_delete=1)
        Software.objects.filter(app_id=app_id).update(is_delete=1)
        app.is_delete = 1
        app.save()
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted Application Server ID {app_id} ({app.name}) and linked software"
        )
    return redirect('list_application_server')


def delete_database_server(request, db_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_database_server')
    db_server = get_object_or_404(DatabaseServer, pk=db_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        schema_ids = list(SchemaInfo.objects.filter(database_server_id=db_id)
                          .values_list('db_id', flat=True))
        if schema_ids:
            SoftwareDatabaseMap.objects.filter(db_id__in=schema_ids).update(is_delete=1)
        SchemaInfo.objects.filter(database_server_id=db_id).update(is_delete=1)
        db_server.is_delete = 1
        db_server.save()
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted Database Server ID {db_id} ({db_server.name}) and linked schemas"
        )
    return redirect('list_database_server')


def delete_schema_info(request, db_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_schema_info')
    schema = get_object_or_404(SchemaInfo, pk=db_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        SoftwareDatabaseMap.objects.filter(db_id=db_id).update(is_delete=1)
        schema.is_delete = 1
        schema.save()
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted Schema Info ID {db_id} ({schema.db_name})"
        )
    return redirect('list_schema_info')


def delete_software(request, software_id):
    if not request.session.get('employeecode') or request.session.get('administrator') != '1':
        return redirect('list_software_server')
    software = get_object_or_404(Software, pk=software_id)
    if request.method == 'POST':
        employeecode = request.session.get('employeecode')
        SoftwareDatabaseMap.objects.filter(software_id=software_id).update(is_delete=1)
        software.is_delete = 1
        software.save()
        AuthLog.objects.create(
            username=employeecode, action='soft_deleted',
            details=f"Soft-deleted Software ID {software_id} ({software.name})"
        )
    return redirect('list_software_server')
