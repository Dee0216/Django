from django.db import models
from django.utils import timezone


class PhysicalServer(models.Model):
    server_id = models.AutoField(primary_key=True)
    hostname = models.CharField(max_length=100)
    user_id = models.CharField(max_length=25)
    password = models.CharField(max_length=25)
    make = models.CharField(max_length=100, blank=True, null=True)
    model = models.CharField(max_length=100, blank=True, null=True)
    service_tag = models.CharField(max_length=50, blank=True, null=True)
    purchase_no = models.CharField(max_length=25)
    purchase_date = models.DateField(blank=True, null=True)
    warranty_expiry = models.DateField(blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    ip_address = models.CharField(max_length=45)
    is_delete = models.IntegerField(default=0)

    def __str__(self):
        return self.hostname

    class Meta:
        managed = False
        db_table = 'physical_server'


class VirtualMachine(models.Model):
    vm_id = models.AutoField(primary_key=True)
    hostname = models.CharField(max_length=100)
    user_id = models.CharField(max_length=25)
    password = models.CharField(max_length=25)
    os = models.CharField(max_length=100, blank=True, null=True)
    cpu_cores = models.IntegerField(blank=True, null=True)
    ram_gb = models.IntegerField(blank=True, null=True)
    storage_gb = models.IntegerField(blank=True, null=True)
    ip_address = models.CharField(max_length=50, blank=True, null=True)
    physical_server = models.ForeignKey('PhysicalServer', on_delete=models.CASCADE,
                                        db_column='physical_server_id', blank=True, null=True)
    description = models.CharField(max_length=100, blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    def __str__(self):
        return self.hostname

    class Meta:
        db_table = 'virtual_machine'


class ApplicationServer(models.Model):
    app_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    userid = models.CharField(max_length=50, blank=True, null=True)
    password = models.CharField(max_length=50, blank=True, null=True)
    location = models.CharField(max_length=50, blank=True, null=True)
    focal_point = models.CharField(max_length=50, blank=True, null=True)
    remarks = models.CharField(max_length=150, blank=True, null=True)
    vm = models.ForeignKey('VirtualMachine', on_delete=models.CASCADE,
                           db_column='vm_id', blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    class Meta:
        managed = False
        db_table = 'application_server'


class DatabaseServer(models.Model):
    db_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    focal_point = models.CharField(max_length=100, blank=True, null=True)
    location = models.CharField(max_length=100, blank=True, null=True)
    port = models.IntegerField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    vm = models.ForeignKey('VirtualMachine', on_delete=models.CASCADE,
                           db_column='vm_id', blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    class Meta:
        managed = False
        db_table = 'database_server'


class SchemaInfo(models.Model):
    db_id = models.AutoField(primary_key=True)
    db_type = models.CharField(max_length=50, blank=True, null=True)
    user_id = models.CharField(max_length=25)
    password = models.CharField(max_length=25)
    version = models.CharField(max_length=50, blank=True, null=True)
    port = models.IntegerField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    db_name = models.CharField(max_length=45, blank=True, null=True)
    database_server = models.ForeignKey('DatabaseServer', on_delete=models.CASCADE,
                                        db_column='database_server_id', blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    @property
    def vm(self):
        if self.database_server and self.database_server.vm:
            return self.database_server.vm
        return None

    def __str__(self):
        return self.db_name or f"SchemaInfo {self.db_id}"

    class Meta:
        managed = False
        db_table = 'schema_info'


class Software(models.Model):
    software_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    version = models.CharField(max_length=50, blank=True, null=True)
    app = models.ForeignKey('ApplicationServer', on_delete=models.CASCADE,
                            db_column='type', blank=True, null=True)
    client = models.CharField(max_length=50)
    focal_point = models.CharField(max_length=25)
    programming_language = models.CharField(max_length=25)
    description = models.TextField(blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    @property
    def vm(self):
        if self.app and self.app.vm:
            return self.app.vm
        return None

    class Meta:
        managed = False
        db_table = 'software'


class SoftwareDatabaseMap(models.Model):
    software = models.ForeignKey('Software', on_delete=models.CASCADE,
                                 db_column='software_id', blank=True, null=True)
    db = models.ForeignKey('SchemaInfo', on_delete=models.CASCADE,
                           db_column='db_id', blank=True, null=True)
    description = models.CharField(max_length=200, blank=True, null=True)
    is_delete = models.IntegerField(default=0)

    class Meta:
        managed = False
        db_table = 'software_database_map'


class TblEmpdetails(models.Model):
    employeecode = models.CharField(db_column='EMPLOYEECODE', primary_key=True, max_length=7)
    salutation = models.CharField(db_column='SALUTATION', max_length=10)
    employeename = models.CharField(db_column='EMPLOYEENAME', max_length=100)
    designation = models.CharField(db_column='DESIGNATION', max_length=45)
    desgfullname = models.CharField(db_column='DESGFULLNAME', max_length=75)
    divncode = models.CharField(db_column='DIVNCODE', max_length=10)
    division = models.CharField(db_column='DIVISION', max_length=10)
    grup = models.CharField(db_column='GRUP', max_length=10)
    entity = models.CharField(db_column='ENTITY', max_length=10)
    administrator = models.CharField(db_column='ADMINISTRATOR', max_length=1)
    password = models.CharField(db_column='PASSWORD', max_length=45, blank=True, null=True)

    class Meta:
        db_table = 'tbl_empdetails'

    def __str__(self):
        return f"{self.employeecode} - {self.employeename}"


class AuthLog(models.Model):
    ACTION_CHOICES = [
        ('login', 'Login'), ('logout', 'Logout'), ('failed', 'Failed'),
        ('Viewed Physical server', 'Viewed Physical server'),
        ('Viewed VM list', 'Viewed VM list'),
        ('Viewed Database', 'Viewed Database'),
        ('Viewed Software', 'Viewed Software'),
        ('Viewed Mapping', 'Viewed Mapping'),
        ('Viewed Dashboard', 'Viewed Dashboard'),
        ('Added Physical server', 'Added Physical server'),
        ('Added VM', 'Added VM'),
        ('Added software', 'Added software'),
        ('Added database', 'Added database'),
        ('Added Mappings', 'Added Mappings'),
        ('viewed_edit_server', 'Viewed Edit Server'),
        ('edited_server', 'Edited Server'),
        ('viewed_edit_Software', 'Viewed Edit Software'),
        ('edited_software', 'Edited Software'),
        ('viewed_edit_database', 'Viewed Edit database'),
        ('edited_database', 'Edited Database'),
        ('viewed_edit_vm', 'Viewed Edit vm'),
        ('edited_vm', 'Edited vm'),
        ('Added DatabaseServer', 'Added Database Server'),
        ('Viewed DatabaseServer', 'Viewed Database Server'),
        ('viewed_edit_schema_info', 'Viewed Edit Schema Info'),
        ('edited_schema_info', 'Edited Schema Info'),
        ('viewed_edit_database_server', 'Viewed Edit Database Server'),
        ('edited_database_server', 'Edited Database Server'),
        ('soft_deleted', 'Soft Deleted'),
    ]
    username = models.CharField(max_length=100)
    action = models.CharField(max_length=100, choices=ACTION_CHOICES)
    details = models.TextField(blank=True, null=True)
    time = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-time']

    def __str__(self):
        return f"{self.username} - {self.action} @ {self.time}"
