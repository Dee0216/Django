# =============================================================================
# FILE: admin.py
# ACTION: REPLACE your existing inframap/admin.py with this file entirely.
# =============================================================================
# PURPOSE:
#   Registers all models (including AuditLog) in Django's admin panel at
#   /admin/. The AuditLog admin is read-only — nobody can manually add or
#   delete entries, which protects the integrity of the audit trail.
#
# AUDITLOG ADMIN FEATURES:
#   - Searchable by username, asset label, IP address, or detail text
#   - Filterable by action type and asset type
#   - All fields are readonly (no editing allowed)
#   - Add and delete permissions are disabled
# =============================================================================

from django.contrib import admin
from .models import (PhysicalServer, VirtualMachine, DatabaseServer,
                     Software, ApplicationServer, SoftwareDatabaseMap,
                     AuditLog)


@admin.register(PhysicalServer)
class PhysicalServerAdmin(admin.ModelAdmin):
    list_display  = ('serverid', 'hostname', 'ip_address', 'location', 'status')
    search_fields = ('hostname', 'ip_address', 'location')
    list_filter   = ('status',)


@admin.register(VirtualMachine)
class VirtualMachineAdmin(admin.ModelAdmin):
    list_display  = ('vmid', 'hostname', 'serverid', 'ip_address', 'status')
    search_fields = ('hostname', 'ip_address')
    list_filter   = ('status', 'serverid')
    raw_id_fields = ()


@admin.register(DatabaseServer)
class DatabaseServerAdmin(admin.ModelAdmin):
    list_display  = ('dbserverid', 'hostname', 'vmid', 'engine', 'port', 'status')
    search_fields = ('hostname', 'database_names')
    list_filter   = ('engine', 'status')


@admin.register(Software)
class SoftwareAdmin(admin.ModelAdmin):
    list_display  = ('softwareid', 'name', 'vmid', 'category', 'version')
    search_fields = ('name', 'vendor')
    list_filter   = ('category',)


@admin.register(ApplicationServer)
class ApplicationServerAdmin(admin.ModelAdmin):
    list_display  = ('appserverid', 'hostname', 'vmid', 'server_type', 'port')
    search_fields = ('hostname', 'deployed_apps')
    list_filter   = ('server_type',)


@admin.register(SoftwareDatabaseMap)
class SoftwareDatabaseMapAdmin(admin.ModelAdmin):
    list_display  = ('mapid', 'source_type', 'softwareid', 'appserverid',
                     'dbserverid', 'relationship_type')
    list_filter   = ('source_type', 'relationship_type')


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display    = ('timestamp', 'user', 'ip_address', 'action',
                       'asset_type', 'asset_label', 'asset_id')
    list_filter     = ('action', 'asset_type')
    search_fields   = ('user__username', 'asset_label', 'ip_address', 'detail')
    readonly_fields = ('timestamp', 'user', 'action', 'asset_type',
                       'asset_id', 'asset_label', 'detail', 'ip_address')
    ordering        = ('-timestamp',)

    def has_add_permission(self, request):
        return False    # prevent manual creation of fake audit entries

    def has_delete_permission(self, request, obj=None):
        return False    # prevent deletion to protect audit integrity
