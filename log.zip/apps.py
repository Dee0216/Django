# =============================================================================
# FILE: apps.py
# ACTION: REPLACE your existing inframap/apps.py with this file entirely.
# =============================================================================
# PURPOSE:
#   AppConfig is Django's app configuration class. The key addition here is
#   the ready() method, which Django calls once at startup after all models
#   are loaded. We use it to import signals.py so the login/logout listeners
#   are registered before any requests come in.
#
#   Without this, signals.py would never be imported and login/logout events
#   would NOT be captured in the audit log.
# =============================================================================

from django.apps import AppConfig


class InframapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inframap'

    def ready(self):
        # This import triggers the @receiver decorators in signals.py,
        # registering them with Django's signal dispatcher.
        # The 'noqa' comment suppresses the "imported but unused" linter warning.
        import inframap.signals  # noqa
