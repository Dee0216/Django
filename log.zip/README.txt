================================================================================
  INFRAMAP — AUDIT LOGGING SYSTEM
  Database-only audit trail: who logged in/out, when, and what they did
================================================================================

FILES IN THIS FOLDER
────────────────────
  1. models_audit.py          → AuditLog model (paste into your models.py)
  2. audit_utils.py           → audit() helper function (new file in your app)
  3. signals.py               → login/logout auto-capture (new file in your app)
  4. apps.py                  → registers signals at startup (replace your apps.py)
  5. admin.py                 → Django admin with AuditLog (replace your admin.py)
  6. urls.py                  → adds /audit-log/ route (replace your urls.py)
  7. views.py                 → full views with audit calls (replace your views.py)
  8. audit_log.html           → the log viewer template (new file in templates)


DO THESE STEPS IN ORDER
════════════════════════════════════════════════════════════════════════════════

STEP 1 — Add the AuditLog model
────────────────────────────────
  File: models_audit.py

  Open your existing  inframap/models.py  and paste the entire AuditLog class
  from models_audit.py at the very bottom of the file.

  Do NOT replace models.py — just append to it.

  The AuditLog model creates a new database table called "audit_log" with these
  columns:
    - user        : who did it (FK to Django's User, kept even if user deleted)
    - action      : what happened (LOGIN, CREATE, DELETE, etc.)
    - asset_type  : which model was affected (PhysicalServer, VirtualMachine…)
    - asset_id    : the primary key of the record at the time
    - asset_label : the hostname/name at the time (preserved even after deletion)
    - detail      : extra info (changed fields, form errors, IP on login)
    - ip_address  : the client IP address
    - timestamp   : set automatically, never editable


STEP 2 — Run migrations to create the table
────────────────────────────────────────────
  After saving models.py, run these two commands in your terminal:

    python manage.py makemigrations
    python manage.py migrate

  This creates the physical "audit_log" table in your database.
  You must do this before starting the server or you will get errors.


STEP 3 — Add the audit helper
──────────────────────────────
  File: audit_utils.py

  Copy audit_utils.py into your  inframap/  app folder.
  This file contains one function: audit()

  audit() is called inside every view whenever something happens. It:
    1. Gets the current user from request.user
    2. Gets the client IP address from request.META
    3. Writes one row to the AuditLog table

  You do not need to change anything in this file.


STEP 4 — Add the signals file
──────────────────────────────
  File: signals.py

  Copy signals.py into your  inframap/  app folder.
  Signals are Django's event system — like automatic listeners.

  This file listens for three built-in Django auth events:
    - user_logged_in    : writes a LOGIN row to AuditLog
    - user_logged_out   : writes a LOGOUT row to AuditLog
    - user_login_failed : writes a FORM_ERROR row to AuditLog

  Because these use Django's signal system, they fire automatically for ALL
  login/logout — including through the Django admin panel — without needing
  any code in those views.

  IMPORTANT: This file does nothing unless it is imported at startup.
  That is handled in Step 5 (apps.py).


STEP 5 — Replace apps.py
─────────────────────────
  File: apps.py

  Replace your existing  inframap/apps.py  with this file.
  The only addition is the ready() method:

    def ready(self):
        import inframap.signals  # noqa

  Django calls ready() once at server startup, after all models are loaded.
  Importing signals.py here registers the @receiver decorators with Django's
  signal dispatcher so login/logout events are captured from the very first
  request.

  Without this step, signals.py is never loaded and login/logout will NOT
  be recorded.


STEP 6 — Replace admin.py
──────────────────────────
  File: admin.py

  Replace your existing  inframap/admin.py  with this file.
  Your original admin registrations are all preserved.

  The new addition is @admin.register(AuditLog) which makes the audit log
  visible in Django admin at /admin/inframap/auditlog/

  The AuditLog admin is intentionally read-only:
    - has_add_permission returns False    → can't manually create fake entries
    - has_delete_permission returns False → can't erase the audit trail
    - all fields are in readonly_fields   → can't edit existing entries


STEP 7 — Replace urls.py
─────────────────────────
  File: urls.py

  Replace your existing  inframap/urls.py  with this file.
  All your original routes are preserved.

  The only addition is this new route at the bottom:
    path('audit-log/', views.audit_log_view, name='audit_log')

  This makes the audit log viewer available at /audit-log/
  The viewer lets you filter by user, action type, and asset type.


STEP 8 — Replace views.py
──────────────────────────
  File: views.py

  Replace your existing  inframap/views.py  with this file.
  Every view is the same as before but with these additions:

  a) @login_required decorator on every view
     → Redirects to login page if user is not authenticated.
     → Make sure LOGIN_URL is set in settings.py (default is /accounts/login/)

  b) audit() call after every successful form.save()
     → Records CREATE or UPDATE with the asset's name and ID

  c) audit() call before every .delete()
     → Must be BEFORE delete, not after — once deleted the object is gone
     → Captures hostname/name so it's preserved in the log even after deletion

  d) audit() call on every form validation failure
     → Records FORM_ERROR with the full error details as JSON

  e) audit_log_view at the bottom
     → New view that renders the audit_log.html template
     → Supports ?user=, ?action=, ?asset= GET filter params


STEP 9 — Add the template
──────────────────────────
  File: audit_log.html

  Copy audit_log.html to:
    inframap/templates/inframap/audit_log.html

  This is the audit log viewer page. It shows a table of all AuditLog records
  with colour-coded badges per action type:
    GREEN  = LOGIN
    GREY   = LOGOUT
    BLUE   = CREATE / MAP_CREATE
    YELLOW = UPDATE / FORM_ERROR
    RED    = DELETE / MAP_DELETE
    CYAN   = EXPORT

  The detail column is truncated to 80 characters in the cell. Hovering over
  it shows the full text in a browser tooltip.


FINAL CHECKLIST
════════════════════════════════════════════════════════════════════════════════

  [ ] Pasted AuditLog class into the bottom of models.py
  [ ] Ran: python manage.py makemigrations
  [ ] Ran: python manage.py migrate
  [ ] Copied audit_utils.py into inframap/ folder
  [ ] Copied signals.py into inframap/ folder
  [ ] Replaced apps.py
  [ ] Replaced admin.py
  [ ] Replaced urls.py
  [ ] Replaced views.py
  [ ] Copied audit_log.html into inframap/templates/inframap/
  [ ] Restarted the Django development server


WHAT GETS RECORDED
════════════════════════════════════════════════════════════════════════════════

  Event                     Action Code    What's stored in detail
  ─────────────────────────────────────────────────────────────────────────
  User logs in              LOGIN          "Successful login from <IP>"
  User logs out             LOGOUT         "Logged out from <IP>"
  Wrong password            FORM_ERROR     "Failed login for '<username>'"
  Physical server created   CREATE         hostname, new ID
  Virtual machine created   CREATE         hostname, new ID
  DB / Software / AppServer CREATE         name/hostname, new ID
  Any asset edited          UPDATE         hostname + list of changed fields
  Any asset deleted         DELETE         hostname, IP, location (before delete)
  Mapping created           MAP_CREATE     "source → db_hostname [rel_type]"
  Mapping deleted           MAP_DELETE     mapping string representation
  Full JSON export          EXPORT         "Full inframap JSON export"
  Any form submission fails FORM_ERROR     full Django form.errors as JSON


VIEWING THE AUDIT LOG
════════════════════════════════════════════════════════════════════════════════

  Browser:      http://127.0.0.1:8000/audit-log/
  Django Admin: http://127.0.0.1:8000/admin/inframap/auditlog/

  Filter examples:
    /audit-log/?action=DELETE              → all deletions
    /audit-log/?user=john                  → everything john did
    /audit-log/?asset=VirtualMachine       → all VM actions
    /audit-log/?action=LOGIN&user=john     → john's logins only

================================================================================
