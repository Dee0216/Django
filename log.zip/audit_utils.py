# =============================================================================
# FILE: audit_utils.py
# LOCATION: inframap/audit_utils.py  (inside your app folder)
# =============================================================================
# PURPOSE:
#   This is the core helper function used by every view to write audit events
#   directly into the database. It takes the current request + action details
#   and creates one AuditLog row per call.
#
# HOW IT WORKS:
#   - Extracts the logged-in user from request.user
#   - Extracts the client IP address (supports proxies via X-Forwarded-For)
#   - Creates an AuditLog record with all the details
#
# USAGE IN VIEWS:
#   from .audit_utils import audit
#   audit(request, 'CREATE', asset_type='PhysicalServer',
#         asset_id=server.pk, asset_label=server.hostname)
# =============================================================================

from .models import AuditLog


def get_client_ip(request):
    """
    Returns the real IP address of the client.
    Checks X-Forwarded-For header first (set by load balancers / proxies),
    then falls back to REMOTE_ADDR (direct connection IP).
    """
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded:
        return x_forwarded.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR')


def audit(request, action, asset_type=None, asset_id=None,
          asset_label=None, detail=None):
    """
    Writes a single audit event to the AuditLog database table.

    Parameters:
        request     - the Django HttpRequest object (provides user + IP)
        action      - one of: 'LOGIN', 'LOGOUT', 'CREATE', 'UPDATE',
                      'DELETE', 'FORM_ERROR', 'EXPORT', 'MAP_CREATE', 'MAP_DELETE'
        asset_type  - the model name, e.g. 'PhysicalServer', 'VirtualMachine'
        asset_id    - the primary key of the affected record
        asset_label - human-readable name at the time of the action
                      (stored separately so it's preserved even after deletion)
        detail      - any extra info: changed fields, form errors, notes
    """
    user = request.user if request.user.is_authenticated else None

    AuditLog.objects.create(
        user        = user,
        action      = action,
        asset_type  = asset_type,
        asset_id    = asset_id,
        asset_label = asset_label,
        detail      = detail,
        ip_address  = get_client_ip(request),
    )
