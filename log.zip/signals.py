# =============================================================================
# FILE: signals.py
# LOCATION: inframap/signals.py  (inside your app folder)
# =============================================================================
# PURPOSE:
#   Django signals are like event listeners. This file hooks into Django's
#   built-in authentication events so login/logout is ALWAYS captured,
#   even if it goes through Django's default login view or admin panel —
#   you don't have to add any code to those views manually.
#
# SIGNALS USED:
#   user_logged_in    - fires after a successful login
#   user_logged_out   - fires after a logout
#   user_login_failed - fires when someone submits wrong credentials
#
# IMPORTANT:
#   This file does nothing on its own. It must be imported at startup.
#   This is done in apps.py via the ready() method (see apps.py file).
# =============================================================================

from django.contrib.auth.signals import (
    user_logged_in,
    user_logged_out,
    user_login_failed,
)
from django.dispatch import receiver
from .models import AuditLog


def _get_ip(request):
    """Extract IP, checking proxy headers first."""
    if not request:
        return None
    x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded:
        return x_forwarded.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR')


@receiver(user_logged_in)
def on_login(sender, request, user, **kwargs):
    """Fires automatically every time a user successfully logs in."""
    ip = _get_ip(request)
    AuditLog.objects.create(
        user        = user,
        action      = 'LOGIN',
        asset_type  = 'Auth',
        asset_label = user.username,
        detail      = f"Successful login from {ip}",
        ip_address  = ip,
    )


@receiver(user_logged_out)
def on_logout(sender, request, user, **kwargs):
    """Fires automatically every time a user logs out."""
    ip       = _get_ip(request)
    username = user.username if user else 'unknown'
    AuditLog.objects.create(
        user        = user,
        action      = 'LOGOUT',
        asset_type  = 'Auth',
        asset_label = username,
        detail      = f"Logged out from {ip}",
        ip_address  = ip,
    )


@receiver(user_login_failed)
def on_login_failed(sender, credentials, request, **kwargs):
    """
    Fires when someone submits the login form with wrong credentials.
    The user object is None here because authentication failed —
    we only know the attempted username from credentials dict.
    """
    ip       = _get_ip(request)
    attempted = credentials.get('username', 'unknown')
    AuditLog.objects.create(
        user        = None,           # no user — login failed
        action      = 'FORM_ERROR',
        asset_type  = 'Auth',
        asset_label = attempted,
        detail      = f"Failed login attempt for username='{attempted}' from {ip}",
        ip_address  = ip,
    )
