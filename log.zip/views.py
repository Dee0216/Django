# =============================================================================
# FILE: views.py
# ACTION: REPLACE your existing inframap/views.py with this file entirely.
# =============================================================================
# PURPOSE:
#   This is your full views.py with audit() calls added to every action.
#   The audit() function writes one database row per event.
#
# WHAT CHANGED FROM YOUR ORIGINAL:
#   1. Added:  from .models import AuditLog
#              from .audit_utils import audit
#   2. Added @login_required decorator to every view (redirects to login page
#      if the user isn't authenticated)
#   3. After every successful form.save() → audit(..., 'CREATE' or 'UPDATE')
#   4. Before every .delete() call → audit(..., 'DELETE')
#      (captured BEFORE deletion so we still have the label/hostname)
#   5. On every form.is_valid() == False → audit(..., 'FORM_ERROR')
#   6. Added audit_log_view at the bottom — the log viewer page
#
# HOW audit() IS CALLED:
#   audit(request, ACTION, asset_type, asset_id, asset_label, detail)
#   - request     : always passed so we can get user + IP
#   - ACTION      : string constant from AuditLog.ACTION_CHOICES
#   - asset_type  : model class name as a string
#   - asset_id    : the primary key of the record
#   - asset_label : human-readable name (hostname, software name, etc.)
#   - detail      : extra info — changed fields, form errors, relationship type
# =============================================================================

import json

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import JsonResponse

from .models import (PhysicalServer, VirtualMachine, DatabaseServer,
                     Software, ApplicationServer, SoftwareDatabaseMap,
                     AuditLog)
from .forms  import (PhysicalServerForm, VirtualMachineForm, DatabaseServerForm,
                     SoftwareForm, ApplicationServerForm, SoftwareDatabaseMapForm)
from .audit_utils import audit


# ── helpers ───────────────────────────────────────────────────────────────────
def _base_context():
    """Counts injected into every page (navbar / sidebar badges)."""
    return {
        'server_count':   PhysicalServer.objects.count(),
        'vm_count':       VirtualMachine.objects.count(),
        'db_count':       DatabaseServer.objects.count(),
        'software_count': Software.objects.count() + ApplicationServer.objects.count(),
        'mapping_count':  SoftwareDatabaseMap.objects.count(),
        'asset_count':    (DatabaseServer.objects.count() +
                           Software.objects.count() +
                           ApplicationServer.objects.count()),
    }


# ── Dashboard ─────────────────────────────────────────────────────────────────
@login_required
def dashboard(request):
    servers = PhysicalServer.objects.prefetch_related(
        'virtual_machines__db_servers',
        'virtual_machines__software',
        'virtual_machines__app_servers',
    ).all()
    ctx = _base_context()
    ctx.update({'servers': servers})
    return render(request, 'inframap/dashboard.html', ctx)


# ── Topology ──────────────────────────────────────────────────────────────────
@login_required
def topology(request):
    servers = PhysicalServer.objects.prefetch_related(
        'virtual_machines__db_servers',
        'virtual_machines__software',
        'virtual_machines__app_servers',
    ).all()
    ctx = _base_context()
    ctx.update({'servers': servers})
    return render(request, 'inframap/topology.html', ctx)


# ── Add Assets ────────────────────────────────────────────────────────────────
@login_required
def asset_add(request):
    ctx = _base_context()
    ctx.update({
        'active_tab':  request.GET.get('tab', 'server'),
        'server_form': PhysicalServerForm(),
        'vm_form':     VirtualMachineForm(),
        'db_form':     DatabaseServerForm(),
        'sw_form':     SoftwareForm(),
        'as_form':     ApplicationServerForm(),
    })
    return render(request, 'inframap/asset_add.html', ctx)


# ── Add Physical Server ───────────────────────────────────────────────────────
@login_required
def add_server(request):
    if request.method == 'POST':
        form = PhysicalServerForm(request.POST)
        if form.is_valid():
            server = form.save()
            # AUDIT: record who created this server and its details
            audit(request, 'CREATE',
                  asset_type='PhysicalServer',
                  asset_id=server.serverid,
                  asset_label=server.hostname)
            messages.success(request, '✅ Physical Server added successfully.')
            return redirect('asset_add')
        else:
            # AUDIT: record the validation failure with full error details
            audit(request, 'FORM_ERROR',
                  asset_type='PhysicalServer',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'server',
                'server_form': form,
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add Virtual Machine ───────────────────────────────────────────────────────
@login_required
def add_vm(request):
    if request.method == 'POST':
        form = VirtualMachineForm(request.POST)
        if form.is_valid():
            vm = form.save()
            audit(request, 'CREATE',
                  asset_type='VirtualMachine',
                  asset_id=vm.vmid,
                  asset_label=vm.hostname)
            messages.success(request, '✅ Virtual Machine added successfully.')
            return redirect('asset_add')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='VirtualMachine',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'vm',
                'server_form': PhysicalServerForm(),
                'vm_form':     form,
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add DB Server ─────────────────────────────────────────────────────────────
@login_required
def add_db_server(request):
    if request.method == 'POST':
        form = DatabaseServerForm(request.POST)
        if form.is_valid():
            db = form.save()
            audit(request, 'CREATE',
                  asset_type='DatabaseServer',
                  asset_id=db.dbserverid,
                  asset_label=db.hostname)
            messages.success(request, '✅ Database Server added successfully.')
            return redirect('asset_add')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='DatabaseServer',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'db',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     form,
                'sw_form':     SoftwareForm(),
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add Software ──────────────────────────────────────────────────────────────
@login_required
def add_software(request):
    if request.method == 'POST':
        form = SoftwareForm(request.POST)
        if form.is_valid():
            sw = form.save()
            audit(request, 'CREATE',
                  asset_type='Software',
                  asset_id=sw.softwareid,
                  asset_label=sw.name)
            messages.success(request, '✅ Software added successfully.')
            return redirect('asset_add')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='Software',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'software',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     form,
                'as_form':     ApplicationServerForm(),
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Add App Server ────────────────────────────────────────────────────────────
@login_required
def add_app_server(request):
    if request.method == 'POST':
        form = ApplicationServerForm(request.POST)
        if form.is_valid():
            app = form.save()
            audit(request, 'CREATE',
                  asset_type='ApplicationServer',
                  asset_id=app.appserverid,
                  asset_label=app.hostname)
            messages.success(request, '✅ App Server added successfully.')
            return redirect('asset_add')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='ApplicationServer',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please fix the errors below.')
            ctx = _base_context()
            ctx.update({
                'active_tab':  'appserver',
                'server_form': PhysicalServerForm(),
                'vm_form':     VirtualMachineForm(),
                'db_form':     DatabaseServerForm(),
                'sw_form':     SoftwareForm(),
                'as_form':     form,
            })
            return render(request, 'inframap/asset_add.html', ctx)
    return redirect('asset_add')


# ── Map Relations ─────────────────────────────────────────────────────────────
@login_required
def map_relations(request):
    form     = SoftwareDatabaseMapForm()
    mappings = SoftwareDatabaseMap.objects.select_related(
        'softwareid', 'appserverid', 'dbserverid'
    ).all()
    ctx = _base_context()
    ctx.update({'form': form, 'mappings': mappings})
    return render(request, 'inframap/map_relations.html', ctx)


@login_required
def add_mapping(request):
    if request.method == 'POST':
        form = SoftwareDatabaseMapForm(request.POST)
        if form.is_valid():
            source   = form.cleaned_data['source']
            dbserver = form.cleaned_data['dbserverid']
            rel_type = form.cleaned_data['relationship_type']
            notes    = form.cleaned_data['notes']

            prefix, pk = source.split(':')
            mapping = SoftwareDatabaseMap(dbserverid=dbserver,
                                          relationship_type=rel_type,
                                          notes=notes)
            if prefix == 'sw':
                mapping.source_type = 'software'
                mapping.softwareid  = Software.objects.get(pk=pk)
                source_label        = str(mapping.softwareid)
            else:
                mapping.source_type = 'appserver'
                mapping.appserverid = ApplicationServer.objects.get(pk=pk)
                source_label        = str(mapping.appserverid)
            mapping.save()

            audit(request, 'MAP_CREATE',
                  asset_type='SoftwareDatabaseMap',
                  asset_id=mapping.mapid,
                  asset_label=f"{source_label} → {dbserver.hostname}",
                  detail=f"relationship_type={rel_type}")
            messages.success(request, '✅ Mapping created successfully.')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='SoftwareDatabaseMap',
                  detail=f"Form errors: {form.errors.as_json()}")
            messages.error(request, '⚠️ Please select both fields.')
    return redirect('map_relations')


@login_required
def delete_mapping(request, pk):
    mapping = get_object_or_404(SoftwareDatabaseMap, pk=pk)
    label   = str(mapping)
    # AUDIT before delete so we still have the label
    audit(request, 'MAP_DELETE',
          asset_type='SoftwareDatabaseMap',
          asset_id=pk,
          asset_label=label)
    mapping.delete()
    messages.success(request, '🗑️ Mapping deleted.')
    return redirect('map_relations')


# ── Physical Servers List ─────────────────────────────────────────────────────
@login_required
def servers_list(request):
    q       = request.GET.get('q', '')
    servers = PhysicalServer.objects.prefetch_related('virtual_machines').all()
    if q:
        servers = servers.filter(
            Q(hostname__icontains=q) |
            Q(ip_address__icontains=q) |
            Q(location__icontains=q) |
            Q(os__icontains=q)
        )
    ctx = _base_context()
    ctx.update({'servers': servers, 'q': q})
    return render(request, 'inframap/servers_list.html', ctx)


@login_required
def server_detail(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    vms    = server.virtual_machines.prefetch_related('db_servers', 'software', 'app_servers').all()
    ctx = _base_context()
    ctx.update({'server': server, 'vms': vms})
    return render(request, 'inframap/server_detail.html', ctx)


@login_required
def server_edit(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    if request.method == 'POST':
        form = PhysicalServerForm(request.POST, instance=server)
        if form.is_valid():
            changed = form.changed_data   # list of field names that were modified
            form.save()
            audit(request, 'UPDATE',
                  asset_type='PhysicalServer',
                  asset_id=pk,
                  asset_label=server.hostname,
                  detail=f"Changed fields: {', '.join(changed)}")
            messages.success(request, '✅ Server updated.')
            return redirect('servers_list')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='PhysicalServer',
                  asset_id=pk,
                  asset_label=server.hostname,
                  detail=f"Form errors: {form.errors.as_json()}")
    else:
        form = PhysicalServerForm(instance=server)
    ctx = _base_context()
    ctx.update({'form': form, 'server': server})
    return render(request, 'inframap/server_edit.html', ctx)


@login_required
def server_delete(request, pk):
    server = get_object_or_404(PhysicalServer, pk=pk)
    # AUDIT before delete — after delete the object no longer exists
    audit(request, 'DELETE',
          asset_type='PhysicalServer',
          asset_id=pk,
          asset_label=server.hostname,
          detail=f"ip={server.ip_address}, location={server.location}")
    server.delete()
    messages.success(request, '🗑️ Server deleted.')
    return redirect('servers_list')


# ── VMs List ──────────────────────────────────────────────────────────────────
@login_required
def vms_list(request):
    q   = request.GET.get('q', '')
    vms = VirtualMachine.objects.select_related('serverid').all()
    if q:
        vms = vms.filter(
            Q(hostname__icontains=q) |
            Q(ip_address__icontains=q) |
            Q(role__icontains=q) |
            Q(serverid__hostname__icontains=q)
        )
    ctx = _base_context()
    ctx.update({'vms': vms, 'q': q})
    return render(request, 'inframap/vms_list.html', ctx)


@login_required
def vm_edit(request, pk):
    vm = get_object_or_404(VirtualMachine, pk=pk)
    if request.method == 'POST':
        form = VirtualMachineForm(request.POST, instance=vm)
        if form.is_valid():
            changed = form.changed_data
            form.save()
            audit(request, 'UPDATE',
                  asset_type='VirtualMachine',
                  asset_id=pk,
                  asset_label=vm.hostname,
                  detail=f"Changed fields: {', '.join(changed)}")
            messages.success(request, '✅ VM updated.')
            return redirect('vms_list')
        else:
            audit(request, 'FORM_ERROR',
                  asset_type='VirtualMachine',
                  asset_id=pk,
                  asset_label=vm.hostname,
                  detail=f"Form errors: {form.errors.as_json()}")
    else:
        form = VirtualMachineForm(instance=vm)
    ctx = _base_context()
    ctx.update({'form': form, 'vm': vm})
    return render(request, 'inframap/vm_edit.html', ctx)


@login_required
def vm_delete(request, pk):
    vm = get_object_or_404(VirtualMachine, pk=pk)
    # AUDIT before delete
    audit(request, 'DELETE',
          asset_type='VirtualMachine',
          asset_id=pk,
          asset_label=vm.hostname,
          detail=f"host_server={vm.serverid.hostname}")
    vm.delete()
    messages.success(request, '🗑️ VM deleted.')
    return redirect('vms_list')


# ── Software List ─────────────────────────────────────────────────────────────
@login_required
def software_list(request):
    software    = Software.objects.select_related('vmid').all()
    db_servers  = DatabaseServer.objects.select_related('vmid').all()
    app_servers = ApplicationServer.objects.select_related('vmid').all()
    ctx = _base_context()
    ctx.update({
        'software':    software,
        'db_servers':  db_servers,
        'app_servers': app_servers,
    })
    return render(request, 'inframap/software_list.html', ctx)


# ── Export JSON ───────────────────────────────────────────────────────────────
@login_required
def export_json(request):
    # AUDIT: record who triggered the full data export and when
    audit(request, 'EXPORT',
          asset_type='AllAssets',
          detail="Full inframap JSON export")
    data = {
        'physical_servers': list(PhysicalServer.objects.values()),
        'virtual_machines': list(VirtualMachine.objects.values()),
        'database_servers': list(DatabaseServer.objects.values()),
        'software':         list(Software.objects.values()),
        'app_servers':      list(ApplicationServer.objects.values()),
        'mappings':         list(SoftwareDatabaseMap.objects.values()),
    }
    response = JsonResponse(data, json_dumps_params={'indent': 2})
    response['Content-Disposition'] = 'attachment; filename="inframap-export.json"'
    return response


# ── Audit Log Viewer ──────────────────────────────────────────────────────────
@login_required
def audit_log_view(request):
    """
    Renders the audit log viewer page at /audit-log/
    Supports optional GET filters:
      ?user=john          → filter by username (partial match)
      ?action=DELETE      → filter by exact action code
      ?asset=PhysicalServer → filter by asset type (partial match)
    Results are capped at 500 rows for page performance.
    """
    logs = AuditLog.objects.select_related('user').all()

    filter_user   = request.GET.get('user', '')
    filter_action = request.GET.get('action', '')
    filter_asset  = request.GET.get('asset', '')

    if filter_user:
        logs = logs.filter(user__username__icontains=filter_user)
    if filter_action:
        logs = logs.filter(action=filter_action)
    if filter_asset:
        logs = logs.filter(asset_type__icontains=filter_asset)

    ctx = _base_context()
    ctx.update({
        'logs':           logs[:500],
        'filter_user':    filter_user,
        'filter_action':  filter_action,
        'filter_asset':   filter_asset,
        'action_choices': AuditLog.ACTION_CHOICES,
    })
    return render(request, 'inframap/audit_log.html', ctx)
