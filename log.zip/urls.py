# =============================================================================
# FILE: urls.py
# ACTION: REPLACE your existing inframap/urls.py with this file entirely.
# =============================================================================
# PURPOSE:
#   Maps URL paths to view functions. The only change from your original
#   urls.py is the addition of the audit-log/ route at the bottom.
#
# NEW ROUTE:
#   /audit-log/  →  views.audit_log_view
#   This renders the audit log viewer page where you can filter and browse
#   all recorded events by user, action type, or asset type.
# =============================================================================

from django.urls import path
from . import views

urlpatterns = [

    # ── Dashboard & Topology ──────────────────────────
    path('',                     views.dashboard,       name='dashboard'),
    path('topology/',            views.topology,        name='topology'),

    # ── Add Assets (tabbed page + individual POST handlers) ──
    path('assets/add/',          views.asset_add,       name='asset_add'),
    path('assets/add/server/',   views.add_server,      name='add_server'),
    path('assets/add/vm/',       views.add_vm,          name='add_vm'),
    path('assets/add/db/',       views.add_db_server,   name='add_db_server'),
    path('assets/add/software/', views.add_software,    name='add_software'),
    path('assets/add/appserver/',views.add_app_server,  name='add_app_server'),

    # ── Map Relations ─────────────────────────────────
    path('map/',                 views.map_relations,   name='map_relations'),
    path('map/add/',             views.add_mapping,     name='add_mapping'),
    path('map/delete/<int:pk>/', views.delete_mapping,  name='mapping_delete'),

    # ── Physical Servers ──────────────────────────────
    path('servers/',                  views.servers_list,  name='servers_list'),
    path('servers/<int:pk>/',         views.server_detail, name='server_detail'),
    path('servers/<int:pk>/edit/',    views.server_edit,   name='server_edit'),
    path('servers/<int:pk>/delete/',  views.server_delete, name='server_delete'),

    # ── Virtual Machines ──────────────────────────────
    path('vms/',                      views.vms_list,      name='vms_list'),
    path('vms/<int:pk>/edit/',        views.vm_edit,       name='vm_edit'),
    path('vms/<int:pk>/delete/',      views.vm_delete,     name='vm_delete'),

    # ── Software / DB / App Servers list ─────────────
    path('software/',                 views.software_list, name='software_list'),

    # ── Export ────────────────────────────────────────
    path('export/',                   views.export_json,   name='export_json'),

    # ── Audit Log Viewer ──────────────────────────────
    # NEW: browse and filter all audit events at /audit-log/
    path('audit-log/',                views.audit_log_view, name='audit_log'),
]
