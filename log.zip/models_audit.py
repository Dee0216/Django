# =============================================================================
# FILE: models_audit.py
# ACTION: Copy the AuditLog class below and PASTE it at the bottom of your
#         existing  inframap/models.py  file.
# =============================================================================
# PURPOSE:
#   Defines the AuditLog database table. Every login, logout, create, update,
#   delete, form error, export, and mapping action gets one row here.
#
# FIELDS EXPLAINED:
#   user        - ForeignKey to Django's built-in User. SET_NULL means the
#                 log row is kept even if the user account is deleted.
#   action      - What happened (LOGIN, CREATE, DELETE, etc.)
#   asset_type  - Which model was affected (e.g. 'PhysicalServer')
#   asset_id    - The primary key of that record at the time of the action
#   asset_label - The hostname/name at the time of the action. Stored as a
#                 plain string so it survives even after the record is deleted.
#   detail      - Extra context: which fields changed, form error messages, etc.
#   ip_address  - The IP of the user who performed the action
#   timestamp   - Set automatically when the row is created (auto_now_add)
# =============================================================================

from django.db import models
from django.contrib.auth.models import User


class AuditLog(models.Model):

    ACTION_CHOICES = [
        ('LOGIN',      'Login'),
        ('LOGOUT',     'Logout'),
        ('CREATE',     'Created'),
        ('UPDATE',     'Updated'),
        ('DELETE',     'Deleted'),
        ('FORM_ERROR', 'Form Validation Failed'),
        ('EXPORT',     'Exported Data'),
        ('MAP_CREATE', 'Mapping Created'),
        ('MAP_DELETE', 'Mapping Deleted'),
    ]

    user        = models.ForeignKey(User, on_delete=models.SET_NULL,
                                    null=True, blank=True,
                                    related_name='audit_logs')
    action      = models.CharField(max_length=20, choices=ACTION_CHOICES)
    asset_type  = models.CharField(max_length=100, blank=True, null=True)
    asset_id    = models.IntegerField(blank=True, null=True)
    asset_label = models.CharField(max_length=255, blank=True, null=True)
    detail      = models.TextField(blank=True, null=True)
    ip_address  = models.GenericIPAddressField(blank=True, null=True)
    timestamp   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table            = 'audit_log'
        ordering            = ['-timestamp']   # newest first
        verbose_name        = 'Audit Log'
        verbose_name_plural = 'Audit Logs'

    def __str__(self):
        username = self.user.username if self.user else 'Anonymous'
        return f"[{self.timestamp:%Y-%m-%d %H:%M}] {username} → {self.action} {self.asset_type or ''}"
